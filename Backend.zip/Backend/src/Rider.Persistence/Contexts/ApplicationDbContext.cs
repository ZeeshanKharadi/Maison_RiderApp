using Microsoft.EntityFrameworkCore;
using Rider.Domain.Entities;

namespace Rider.Persistence.Contexts
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AppUser> Users { get; set; }
        public DbSet<OtpCode> Otps { get; set; }
        public DbSet<UserRefreshToken> UserRefreshTokens { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<Store> Stores { get; set; }
        public DbSet<AppSetting> AppSettings { get; set; }
        public DbSet<AssignedOrderBatch> AssignedOrderBatches { get; set; }
        public DbSet<AssignedOrder> AssignedOrders { get; set; }
        public DbSet<AssignedOrderItem> AssignedOrderItems { get; set; }
        public DbSet<RiderNotification> RiderNotifications { get; set; }
        public DbSet<UserDeviceToken> UserDeviceTokens { get; set; }
        public DbSet<PasswordResetToken> PasswordResetTokens { get; set; }
        public DbSet<OrderLifecycleAudit> OrderLifecycleAudits { get; set; }
        public DbSet<OrderRejection> OrderRejections { get; set; }
        public DbSet<DeliveryIssueReport> DeliveryIssueReports { get; set; }
        public DbSet<DeliveryIssueTriageEvent> DeliveryIssueTriageEvents { get; set; }
        public DbSet<RiderAvailabilityInterval> RiderAvailabilityIntervals { get; set; }
        public DbSet<AdminNotification> AdminNotifications { get; set; }
        public DbSet<RiderFloatLedger> RiderFloatLedgers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AppUser>(entity =>
            {
                entity.ToTable("Users");
                entity.HasKey(e => e.UserId);
                entity.HasIndex(e => e.ThirdPartyEmployeeId);
                entity.Property(e => e.PasswordEncrypted).HasColumnName("passwordencrypted");
                entity.Property(e => e.PasswordHash).HasMaxLength(500);
                entity.Property(e => e.ThirdPartyEmployeeId).HasColumnName("ThirdPartyEmployeeId");
                entity.Property(e => e.UserName).HasColumnName("Username");
                entity.Property(e => e.Cnic).HasColumnName("cnic");
                entity.Property(e => e.PhoneNumber).HasColumnName("phoneNumber");
                entity.Property(e => e.EmergencyContactNumber).HasMaxLength(50);
                entity.Property(e => e.EmergencyContactName).HasMaxLength(200);
                entity.Property(e => e.Department).HasColumnName("department");
                entity.Property(e => e.CostCenter).HasColumnName("costCenter");
                entity.Property(e => e.StoreId).HasMaxLength(50);
                entity.Property(e => e.IsAvailableOnline).HasDefaultValue(false);
                entity.Property(e => e.TokenVersion).HasDefaultValue(0);
            });

            modelBuilder.Entity<OtpCode>(entity =>
            {
                entity.ToTable("OTP");
                entity.HasKey(e => e.OtpId);
                entity.Property(e => e.OtpCodeValue).HasColumnName("OtpCode");
                entity.Property(e => e.Purpose).HasMaxLength(40).HasDefaultValue("PasswordReset");
                entity.Property(e => e.AttemptCount).HasDefaultValue(0);
                entity.HasOne(e => e.User)
                    .WithMany(u => u.Otps)
                    .HasForeignKey(e => e.UserId);
            });

            modelBuilder.Entity<UserRefreshToken>(entity =>
            {
                entity.ToTable("UserRefreshTokens");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");
                entity.HasOne(e => e.User)
                    .WithMany(u => u.RefreshTokens)
                    .HasForeignKey(e => e.UserId);
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Roles");
                entity.HasKey(e => e.RoleId);
                entity.Property(e => e.RoleName).HasMaxLength(100).IsRequired();
            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.ToTable("UserRoles");
                entity.HasKey(e => e.UserRoleId);
                entity.HasOne(e => e.User)
                    .WithMany(u => u.UserRoles)
                    .HasForeignKey(e => e.UserId);
                entity.HasOne(e => e.Role)
                    .WithMany(r => r.UserRoles)
                    .HasForeignKey(e => e.RoleId);
            });

            modelBuilder.Entity<Store>(entity =>
            {
                entity.ToTable("Stores");
                entity.HasKey(e => e.StoreId);
                entity.Property(e => e.StoreId).HasMaxLength(50);
                entity.Property(e => e.Name).HasMaxLength(200);
                entity.Property(e => e.Latitude);
                entity.Property(e => e.Longitude);
            });

            modelBuilder.Entity<AppSetting>(entity =>
            {
                entity.ToTable("AppSettings");
                entity.HasKey(e => e.SettingKey);
                entity.Property(e => e.SettingKey).HasMaxLength(100);
                entity.Property(e => e.SettingValue).HasMaxLength(500).IsRequired();
            });

            modelBuilder.Entity<AssignedOrderBatch>(entity =>
            {
                entity.ToTable("AssignedOrderBatches");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Time).HasColumnName("Time").HasMaxLength(50);
                entity.Property(e => e.StoreId).HasMaxLength(50).IsRequired();
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");
                entity.HasOne(e => e.Store)
                    .WithMany()
                    .HasForeignKey(e => e.StoreId)
                    .HasPrincipalKey(s => s.StoreId)
                    .IsRequired(false);
                entity.HasMany(e => e.Orders)
                    .WithOne(o => o.Batch)
                    .HasForeignKey(o => o.BatchId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<AssignedOrder>(entity =>
            {
                entity.ToTable("AssignedOrders");
                entity.HasKey(e => e.Id);
                entity.HasIndex(e => e.OrderId).IsUnique();
                entity.Property(e => e.OrderId).HasMaxLength(50).IsRequired();
                entity.Property(e => e.OrderNo).HasMaxLength(50);
                entity.Property(e => e.OrderTypeId).HasMaxLength(20);
                entity.Property(e => e.OrderState).HasMaxLength(50);
                entity.Property(e => e.Comment).HasMaxLength(500);
                entity.Property(e => e.LastName).HasMaxLength(100);
                entity.Property(e => e.FirstName).HasMaxLength(100);
                entity.Property(e => e.City).HasMaxLength(100);
                entity.Property(e => e.Street).HasMaxLength(200);
                entity.Property(e => e.AddressNo).HasMaxLength(50);
                entity.Property(e => e.PostCode).HasMaxLength(50);
                entity.Property(e => e.SecondaryAddress).HasMaxLength(200);
                entity.Property(e => e.Phone).HasMaxLength(50);
                entity.Property(e => e.OrderTotal).HasColumnType("decimal(18,2)");
                entity.Property(e => e.PaymentMethod).HasMaxLength(20);
                entity.Property(e => e.Cash).HasColumnType("decimal(18,2)");
                entity.Property(e => e.CashCollected).HasColumnType("decimal(18,2)");
                entity.Property(e => e.ExpectedCash).HasColumnType("decimal(18,2)");
                entity.Property(e => e.CashCollectedReason).HasMaxLength(500);
                entity.Property(e => e.CashHandedOverAmount).HasColumnType("decimal(18,2)");
                entity.Property(e => e.CashSemanticsNote).HasMaxLength(100);
                entity.Property(e => e.CancelReason).HasMaxLength(500);
                entity.Property(e => e.IsDirectAssignment).HasDefaultValue(false);
                entity.Property(e => e.HandoverRequestId).HasMaxLength(100);
                entity.HasIndex(e => e.HandoverRequestId)
                    .IsUnique()
                    .HasFilter("[HandoverRequestId] IS NOT NULL");
                entity.Property(e => e.FailureRequestStatus).HasMaxLength(30);
                entity.Property(e => e.FailureReasonCode).HasMaxLength(40);
                entity.Property(e => e.FailureNote).HasMaxLength(500);
                entity.Property(e => e.FailureRequestId).HasMaxLength(100);
                entity.HasIndex(e => e.FailureRequestId)
                    .IsUnique()
                    .HasFilter("[FailureRequestId] IS NOT NULL");
                entity.Property(e => e.FailureDecisionNote).HasMaxLength(500);
                entity.Property(e => e.StatusBeforeReturn).HasMaxLength(30);
                entity.HasOne<DeliveryIssueReport>()
                    .WithMany()
                    .HasForeignKey(e => e.FailureIssueReportId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne<AppUser>()
                    .WithMany()
                    .HasForeignKey(e => e.FailureDecidedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne<AppUser>()
                    .WithMany()
                    .HasForeignKey(e => e.StoreReceivedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.Property(e => e.OrderTime).HasMaxLength(50);
                entity.Property(e => e.Status).HasMaxLength(30).HasDefaultValue("Available");
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");
                if (Database.IsSqlServer())
                    entity.Property(e => e.RowVersion).IsRowVersion();
                else
                    entity.Property(e => e.RowVersion).IsConcurrencyToken();
                entity.HasOne(e => e.AcceptedByUser)
                    .WithMany()
                    .HasForeignKey(e => e.AcceptedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne<AppUser>()
                    .WithMany()
                    .HasForeignKey(e => e.CashHandedOverByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasMany(e => e.Items)
                    .WithOne(i => i.Order)
                    .HasForeignKey(i => i.AssignedOrderId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<AssignedOrderItem>(entity =>
            {
                entity.ToTable("AssignedOrderItems");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.Position).HasMaxLength(50);
                entity.Property(e => e.Comment).HasMaxLength(500);
                entity.Property(e => e.LineNum).HasMaxLength(50);
                entity.Property(e => e.Size).HasMaxLength(50);
            });

            modelBuilder.Entity<RiderNotification>(entity =>
            {
                entity.ToTable("RiderNotifications");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Category).HasMaxLength(30);
                entity.Property(e => e.Title).HasMaxLength(200);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.OrderId).HasMaxLength(50);
                entity.Property(e => e.Priority).HasMaxLength(20);
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("SYSUTCDATETIME()");
                entity.Property(e => e.IsDeleted).HasDefaultValue(false);
                entity.HasIndex(e => new { e.UserId, e.CreatedAt })
                    .HasFilter("[IsDeleted] = 0")
                    .HasDatabaseName("IX_RiderNotifications_User_Active_Created");
                entity.HasOne(e => e.User)
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<UserDeviceToken>(entity =>
            {
                entity.ToTable("UserDeviceTokens");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Token).HasMaxLength(500).IsRequired();
                entity.Property(e => e.Platform).HasMaxLength(20);
                entity.Property(e => e.UpdatedAt).HasDefaultValueSql("SYSUTCDATETIME()");
                entity.HasIndex(e => e.Token).IsUnique();
                entity.HasOne<AppUser>()
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<PasswordResetToken>(entity =>
            {
                entity.ToTable("PasswordResetTokens");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.TokenHash).HasMaxLength(128).IsRequired();
                entity.Property(e => e.Purpose).HasMaxLength(40);
                entity.HasIndex(e => e.TokenHash);
                entity.HasOne(e => e.User)
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<OrderLifecycleAudit>(entity =>
            {
                entity.ToTable("OrderLifecycleAudits");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ActorType).HasMaxLength(30);
                entity.Property(e => e.PreviousStatus).HasMaxLength(30);
                entity.Property(e => e.NewStatus).HasMaxLength(30);
                entity.Property(e => e.Reason).HasMaxLength(500);
                entity.Property(e => e.RequestId).HasMaxLength(100);
                entity.Property(e => e.CashCollected).HasColumnType("decimal(18,2)");
                entity.HasIndex(e => e.RequestId);
                entity.HasOne(e => e.Order)
                    .WithMany()
                    .HasForeignKey(e => e.AssignedOrderId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<OrderRejection>(entity =>
            {
                entity.ToTable("OrderRejections");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Reason).HasMaxLength(500);
                entity.HasIndex(e => new { e.AssignedOrderId, e.RiderUserId }).IsUnique();
                entity.HasOne(e => e.Order)
                    .WithMany()
                    .HasForeignKey(e => e.AssignedOrderId)
                    .OnDelete(DeleteBehavior.Cascade);
                entity.HasOne(e => e.Rider)
                    .WithMany()
                    .HasForeignKey(e => e.RiderUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<DeliveryIssueReport>(entity =>
            {
                entity.ToTable("DeliveryIssueReports");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ReasonCode).HasMaxLength(40).IsRequired();
                entity.Property(e => e.Note).HasMaxLength(500);
                entity.Property(e => e.RequestId).HasMaxLength(100);
                entity.Property(e => e.Status).HasMaxLength(20).IsRequired().HasDefaultValue("New");
                entity.Property(e => e.InternalNote).HasMaxLength(1000);
                entity.HasIndex(e => e.AssignedOrderId);
                entity.HasIndex(e => e.CreatedAt);
                entity.HasIndex(e => new { e.Status, e.CreatedAt });
                entity.HasIndex(e => e.RequestId).IsUnique()
                    .HasFilter("[RequestId] IS NOT NULL");
                if (Database.IsSqlServer())
                    entity.Property(e => e.RowVersion).IsRowVersion();
                else
                    entity.Property(e => e.RowVersion).IsConcurrencyToken();
                entity.HasOne(e => e.Order)
                    .WithMany()
                    .HasForeignKey(e => e.AssignedOrderId)
                    .OnDelete(DeleteBehavior.Cascade);
                entity.HasOne(e => e.Rider)
                    .WithMany()
                    .HasForeignKey(e => e.RiderUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(e => e.AcknowledgedByUser)
                    .WithMany()
                    .HasForeignKey(e => e.AcknowledgedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(e => e.ClosedByUser)
                    .WithMany()
                    .HasForeignKey(e => e.ClosedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<DeliveryIssueTriageEvent>(entity =>
            {
                entity.ToTable("DeliveryIssueTriageEvents");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ActorType).HasMaxLength(30);
                entity.Property(e => e.Action).HasMaxLength(30).IsRequired();
                entity.Property(e => e.PreviousStatus).HasMaxLength(20);
                entity.Property(e => e.NewStatus).HasMaxLength(20);
                entity.Property(e => e.InternalNote).HasMaxLength(1000);
                entity.HasIndex(e => new { e.DeliveryIssueReportId, e.CreatedAt, e.Id });
                entity.HasOne(e => e.Report)
                    .WithMany()
                    .HasForeignKey(e => e.DeliveryIssueReportId)
                    .OnDelete(DeleteBehavior.Cascade);
                entity.HasOne(e => e.Actor)
                    .WithMany()
                    .HasForeignKey(e => e.ActorUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<RiderAvailabilityInterval>(entity =>
            {
                entity.ToTable("RiderAvailabilityIntervals");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.EndReason).HasMaxLength(40);
                entity.HasIndex(e => new { e.UserId, e.EndedAt });
                entity.HasOne(e => e.User)
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<AdminNotification>(entity =>
            {
                entity.ToTable("AdminNotifications");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.StoreId).HasMaxLength(50);
                entity.Property(e => e.Category).HasMaxLength(40);
                entity.Property(e => e.Title).HasMaxLength(200);
                entity.Property(e => e.Body).HasMaxLength(500);
                entity.Property(e => e.OrderId).HasMaxLength(50);
                entity.HasIndex(e => new { e.StoreId, e.CreatedAt });
            });

            modelBuilder.Entity<RiderFloatLedger>(entity =>
            {
                entity.ToTable("RiderFloatLedger");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.StoreId).HasMaxLength(50).IsRequired();
                entity.Property(e => e.Amount).HasColumnType("decimal(18,2)");
                entity.Property(e => e.EntryType).HasMaxLength(20).IsRequired();
                entity.Property(e => e.Status).HasMaxLength(20);
                entity.Property(e => e.AckRequestId).HasMaxLength(100);
                entity.Property(e => e.Reason).HasMaxLength(500);
                entity.Property(e => e.RequestId).HasMaxLength(100).IsRequired();
                entity.HasIndex(e => e.RequestId).IsUnique();
                entity.HasIndex(e => e.AckRequestId).IsUnique()
                    .HasFilter("[AckRequestId] IS NOT NULL");
                entity.HasIndex(e => new { e.RiderUserId, e.CreatedAt });
                entity.HasOne(e => e.RiderUser)
                    .WithMany()
                    .HasForeignKey(e => e.RiderUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(e => e.ActorUser)
                    .WithMany()
                    .HasForeignKey(e => e.ActorUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}
