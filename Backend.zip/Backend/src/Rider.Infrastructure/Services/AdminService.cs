using System.Globalization;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Rider.Application.DTOs.Admin;
using Rider.Application.DTOs.Orders;
using Rider.Application.Helpers;
using Rider.Application.Interfaces;
using Rider.Application.Interfaces.Repositories;
using Rider.Domain.Common;
using Rider.Domain.Entities;
using Rider.Infrastructure.Helpers;

namespace Rider.Infrastructure.Services
{
    public class AdminService : IAdminService
    {
        private static readonly TimeSpan OnlineWindow = TimeSpan.FromMinutes(10);

        private readonly IUnitOfWork _unitOfWork;
        private readonly IPasswordCrypto _passwordCrypto;
        private readonly PasswordVerifier _passwordVerifier;
        private readonly IOpsEventPublisher _opsEvents;
        private readonly IRiderNotificationService _riderNotifications;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AdminService> _logger;

        public AdminService(
            IUnitOfWork unitOfWork,
            IPasswordCrypto passwordCrypto,
            PasswordVerifier passwordVerifier,
            IOpsEventPublisher opsEvents,
            IRiderNotificationService riderNotifications,
            IConfiguration configuration,
            ILogger<AdminService> logger)
        {
            _unitOfWork = unitOfWork;
            _passwordCrypto = passwordCrypto;
            _passwordVerifier = passwordVerifier;
            _opsEvents = opsEvents;
            _riderNotifications = riderNotifications;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<AdminActor> ResolveActorAsync(string userId)
        {
            if (!Guid.TryParse(userId, out var uid))
                return null;

            var user = await _unitOfWork.UserRepository.GetByUserIdAsync(uid);
            if (user == null)
                return null;

            return new AdminActor
            {
                UserId = user.UserId,
                WorkerId = user.ThirdPartyEmployeeId,
                Name = user.UserName,
                StoreId = user.StoreId,
                Roles = RolesOf(user)
            };
        }

        public async Task<ApiResponse<List<AdminRiderDto>>> ListRidersAsync(AdminActor actor, string storeId)
        {
            var scoped = ScopeStore(actor, storeId);
            if (scoped.denied)
                return Fail<List<AdminRiderDto>>(scoped.message);

            var riders = await _unitOfWork.UserRepository.ListRidersAsync(scoped.storeId);
            var stores = await StoreLookupAsync();
            var list = riders.Select(u => MapRider(u, stores)).ToList();
            return Ok(list, "Riders");
        }

        public async Task<ApiResponse<List<AdminLiveRiderDto>>> ListLiveMapRidersAsync(AdminActor actor, string storeId)
        {
            var scoped = ScopeStore(actor, storeId);
            if (scoped.denied)
                return Fail<List<AdminLiveRiderDto>>(scoped.message);

            var staleSeconds = int.TryParse(_configuration["Location:StaleSeconds"], out var ss) && ss > 0
                ? ss
                : 90;

            var riders = await _unitOfWork.UserRepository.ListRidersAsync(scoped.storeId);
            var stores = await StoreLookupAsync();
            var onlineCutoff = DateTime.UtcNow - OnlineWindow;
            var staleBefore = DateTime.UtcNow.AddSeconds(-staleSeconds);

            var result = new List<AdminLiveRiderDto>();
            foreach (var u in riders.Where(r => r.IsActive))
            {
                var active = await _unitOfWork.AssignedOrderRepository.GetActiveForRiderAsync(u.UserId);
                if (active.Count == 0)
                    continue;

                var primary = active
                    .OrderByDescending(o => OrderStatuses.ProgressionIndex(o.Status))
                    .First();

                var hasLocation = u.LastLatitude.HasValue && u.LastLongitude.HasValue && u.LocationUpdatedAt.HasValue;
                var isStale = !hasLocation || u.LocationUpdatedAt < staleBefore;

                result.Add(new AdminLiveRiderDto
                {
                    riderUserId = u.UserId,
                    workerId = u.ThirdPartyEmployeeId,
                    name = u.UserName,
                    storeId = u.StoreId,
                    storeName = stores.TryGetValue(u.StoreId ?? "", out var sn) ? sn : u.StoreId,
                    isOnline = u.IsAvailableOnline
                        && u.LastSeenAt.HasValue
                        && u.LastSeenAt.Value >= onlineCutoff,
                    activeOrderCount = active.Count,
                    deliveryStatus = primary.Status,
                    latitude = u.LastLatitude,
                    longitude = u.LastLongitude,
                    locationUpdatedAt = u.LocationUpdatedAt,
                    hasLocation = hasLocation,
                    isStale = isStale,
                    staleAfterSeconds = staleSeconds
                });
            }

            return Ok(result.OrderBy(r => r.workerId).ToList(), "Live map riders");
        }

        public async Task<ApiResponse<AdminRiderDto>> GetRiderAsync(AdminActor actor, Guid riderId)
        {
            var rider = await _unitOfWork.UserRepository.GetByUserIdAsync(riderId);
            if (rider == null || !IsRider(rider))
                return Fail<AdminRiderDto>("Rider not found");

            if (!CanSeeStore(actor, rider.StoreId))
                return Fail<AdminRiderDto>("Rider not found");

            var stores = await StoreLookupAsync();
            return Ok(MapRider(rider, stores), "Success");
        }

        public async Task<ApiResponse<AdminRiderDto>> CreateRiderAsync(AdminActor actor, CreateRiderRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.workerId) || string.IsNullOrWhiteSpace(request.name))
                return Fail<AdminRiderDto>("workerId and name are required");

            var workerId = request.workerId.Trim();
            if (await _unitOfWork.UserRepository.ExistsAsync(u =>
                    u.ThirdPartyEmployeeId == workerId && u.DeletedAt == null))
                return Fail<AdminRiderDto>("A user with this workerId already exists");

            var storeId = ScopeStore(actor, request.storeId);
            if (storeId.denied)
                return Fail<AdminRiderDto>(storeId.message);

            if (!actor.IsHeadOffice && string.IsNullOrWhiteSpace(storeId.storeId))
                return Fail<AdminRiderDto>("Store is required");

            if (!string.IsNullOrWhiteSpace(request.password) && request.password.Length < 6)
                return Fail<AdminRiderDto>("Password must be at least 6 characters");

            var riderRole = await _unitOfWork.RoleRepository.GetByNameAsync(RoleNames.Rider);
            if (riderRole == null)
                return Fail<AdminRiderDto>("Rider role is not configured");

            if (!string.IsNullOrWhiteSpace(storeId.storeId))
                await _unitOfWork.StoreRepository.EnsureExistsAsync(storeId.storeId, storeId.storeId);

            var hasPassword = !string.IsNullOrWhiteSpace(request.password);
            var user = new AppUser
            {
                UserId = Guid.NewGuid(),
                UserName = request.name.Trim(),
                Email = string.IsNullOrWhiteSpace(request.email)
                    ? $"{workerId.ToLowerInvariant()}@maison.local"
                    : request.email.Trim(),
                PhoneNumber = request.phone?.Trim(),
                ThirdPartyEmployeeId = workerId,
                StoreId = string.IsNullOrWhiteSpace(storeId.storeId) ? null : storeId.storeId,
                IsActive = true,
                IsVerified = hasPassword,
                CreatedAt = DateTime.UtcNow,
                Position = "Rider",
                Department = "Delivery",
                PasswordEncrypted = null
            };

            if (hasPassword)
                _passwordVerifier.SetPassword(user, request.password);

            await _unitOfWork.UserRepository.AddAsync(user);
            await _unitOfWork.UserRoleRepository.AddAsync(new UserRole
            {
                UserId = user.UserId,
                RoleId = riderRole.RoleId,
                AssignedAt = DateTime.UtcNow
            });
            await _unitOfWork.SaveChangesAsync();

            var created = await _unitOfWork.UserRepository.GetByUserIdAsync(user.UserId);
            var stores = await StoreLookupAsync();
            return Ok(MapRider(created, stores), hasPassword
                ? "Rider created"
                : "Rider created. They can set a password via register / OTP.");
        }

        public async Task<ApiResponse<AdminRiderDto>> UpdateRiderAsync(AdminActor actor, Guid riderId, UpdateRiderRequest request)
        {
            var rider = await _unitOfWork.UserRepository.GetByUserIdAsync(riderId);
            if (rider == null || !IsRider(rider))
                return Fail<AdminRiderDto>("Rider not found");

            if (!CanSeeStore(actor, rider.StoreId))
                return Fail<AdminRiderDto>("Rider not found");

            if (!string.IsNullOrWhiteSpace(request?.name))
                rider.UserName = request.name.Trim();
            if (request?.phone != null)
                rider.PhoneNumber = request.phone.Trim();
            if (request?.email != null)
                rider.Email = request.email.Trim();

            if (request?.storeId != null)
            {
                var scoped = ScopeStore(actor, request.storeId);
                if (scoped.denied)
                    return Fail<AdminRiderDto>(scoped.message);

                if (!actor.IsHeadOffice && !string.Equals(scoped.storeId, actor.StoreId, StringComparison.OrdinalIgnoreCase))
                    return Fail<AdminRiderDto>("Cannot assign a rider to another store");

                rider.StoreId = string.IsNullOrWhiteSpace(scoped.storeId) ? null : scoped.storeId;
                if (!string.IsNullOrWhiteSpace(rider.StoreId))
                    await _unitOfWork.StoreRepository.EnsureExistsAsync(rider.StoreId, rider.StoreId);
            }

            if (request?.isActive.HasValue == true)
                rider.IsActive = request.isActive.Value;

            await _unitOfWork.UserRepository.UpdateAsync(rider);
            await _unitOfWork.SaveChangesAsync();

            var stores = await StoreLookupAsync();
            return Ok(MapRider(rider, stores), "Rider updated");
        }

        public async Task<ApiResponse<string>> ResetRiderPasswordAsync(AdminActor actor, Guid riderId, ResetRiderPasswordRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.password) || request.password.Length < 6)
                return Fail<string>("Password must be at least 6 characters");

            var rider = await _unitOfWork.UserRepository.GetByUserIdAsync(riderId);
            if (rider == null || !IsRider(rider))
                return Fail<string>("Rider not found");

            if (!CanSeeStore(actor, rider.StoreId))
                return Fail<string>("Rider not found");

            _passwordVerifier.SetPassword(rider, request.password);
            rider.IsVerified = true;
            await _unitOfWork.UserRepository.UpdateAsync(rider);
            await _unitOfWork.SaveChangesAsync();
            return Ok("", "Password reset");
        }

        public async Task<ApiResponse<string>> SetRiderActiveAsync(AdminActor actor, Guid riderId, bool isActive)
        {
            if (riderId == actor.UserId)
                return Fail<string>("You cannot change your own active status here");

            var rider = await _unitOfWork.UserRepository.GetByUserIdAsync(riderId);
            if (rider == null || !IsRider(rider))
                return Fail<string>("Rider not found");

            if (!CanSeeStore(actor, rider.StoreId))
                return Fail<string>("Rider not found");

            rider.IsActive = isActive;
            await _unitOfWork.UserRepository.UpdateAsync(rider);
            await _unitOfWork.SaveChangesAsync();
            return Ok("", isActive ? "Rider activated" : "Rider deactivated");
        }

        public async Task<ApiResponse<LiveBoardSummaryDto>> GetLiveSummaryAsync(AdminActor actor, string storeId)
        {
            var scoped = ScopeStore(actor, storeId);
            if (scoped.denied)
                return Fail<LiveBoardSummaryDto>(scoped.message);

            var today = DateTime.UtcNow.Date;
            var orders = await _unitOfWork.AssignedOrderRepository
                .QueryForAdminAsync(scoped.storeId, null, null, null, null);

            var riders = await _unitOfWork.UserRepository.ListRidersAsync(scoped.storeId);
            var onlineCutoff = DateTime.UtcNow - OnlineWindow;

            var dto = new LiveBoardSummaryDto
            {
                available = orders.Count(o => o.Status == OrderStatuses.Available),
                accepted = orders.Count(o => o.Status == OrderStatuses.Accepted),
                inProgress = orders.Count(o =>
                    OrderStatuses.IsActiveStatus(o.Status) && o.Status != OrderStatuses.Accepted),
                completedToday = orders.Count(o => o.Status == OrderStatuses.Completed && (o.CompletedAt ?? o.UpdatedAt ?? o.CreatedAt) >= today),
                cancelledToday = orders.Count(o => o.Status == OrderStatuses.Cancelled && (o.UpdatedAt ?? o.CreatedAt) >= today),
                onlineRiders = riders.Count(r => r.IsActive && r.IsAvailableOnline
                    && r.LastSeenAt.HasValue && r.LastSeenAt.Value >= onlineCutoff),
                cashToCollectToday = orders
                    .Where(o => (o.CreatedAt >= today) && IsCash(o.PaymentMethod))
                    .Sum(o => CashOutstandingToStore(o))
            };

            return Ok(dto, "Live summary");
        }

        public async Task<ApiResponse<List<AdminOrderListDto>>> ListOrdersAsync(AdminActor actor, AdminOrderQuery query)
        {
            query ??= new AdminOrderQuery();
            var scoped = ScopeStore(actor, query.storeId);
            if (scoped.denied)
                return Fail<List<AdminOrderListDto>>(scoped.message);

            // Rejected is an event column on Live Ops, not an AssignedOrders.Status value.
            if (string.Equals(query.status, OrderStatuses.Rejected, StringComparison.OrdinalIgnoreCase))
                return Ok(new List<AdminOrderListDto>(), "Orders");

            var (fromUtc, toUtc) = NormalizeRange(query.from, query.to);
            var orders = await _unitOfWork.AssignedOrderRepository
                .QueryForAdminAsync(scoped.storeId, query.status, query.riderId, fromUtc, toUtc);

            return Ok(orders.Select(MapOrderList).ToList(), "Orders");
        }

        public async Task<ApiResponse<List<AdminOrderRejectionDto>>> ListOrderRejectionsAsync(
            AdminActor actor, string storeId, DateTime? from, DateTime? to)
        {
            var scoped = ScopeStore(actor, storeId);
            if (scoped.denied)
                return Fail<List<AdminOrderRejectionDto>>(scoped.message);

            var (fromUtc, toUtc) = NormalizeRange(from, to, defaultDays: 7);

            var q = _unitOfWork.Context.Set<OrderRejection>()
                .AsNoTracking()
                .Include(r => r.Order!).ThenInclude(o => o.Batch)
                .Include(r => r.Rider)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(scoped.storeId))
                q = q.Where(r => r.Order != null && r.Order.Batch != null
                    && r.Order.Batch.StoreId == scoped.storeId);

            if (fromUtc.HasValue)
                q = q.Where(r => r.CreatedAt >= fromUtc.Value);
            if (toUtc.HasValue)
                q = q.Where(r => r.CreatedAt < toUtc.Value);

            var rows = await q.OrderByDescending(r => r.CreatedAt).Take(500).ToListAsync();

            var list = rows.Select(r => new AdminOrderRejectionDto
            {
                id = r.Id,
                assignedOrderId = r.AssignedOrderId,
                orderId = r.Order?.OrderId,
                orderNo = r.Order?.OrderNo,
                storeId = r.Order?.Batch?.StoreId,
                riderUserId = r.RiderUserId,
                riderWorkerId = r.Rider?.ThirdPartyEmployeeId,
                riderName = r.Rider?.UserName,
                reason = r.Reason,
                isDirectAssignment = r.IsDirectAssignment,
                createdAt = r.CreatedAt
            }).ToList();

            return Ok(list, "Order rejections");
        }

        public async Task<ApiResponse<AdminDeliveryIssueReportPageDto>> ListDeliveryIssueReportsAsync(
            AdminActor actor, string storeId, DateTime? from, DateTime? to,
            string status = null, string q = null, bool includeClosed = false,
            int page = 1, int pageSize = 50)
        {
            var scoped = ScopeStore(actor, storeId);
            if (scoped.denied)
                return Fail<AdminDeliveryIssueReportPageDto>(scoped.message);

            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 50;
            if (pageSize > 100) pageSize = 100;

            var statusFilter = string.IsNullOrWhiteSpace(status) ? null : status.Trim();
            if (!string.IsNullOrWhiteSpace(statusFilter)
                && !string.Equals(statusFilter, "Open", StringComparison.OrdinalIgnoreCase)
                && !DeliveryIssueStatuses.IsValid(statusFilter))
            {
                return Fail<AdminDeliveryIssueReportPageDto>(
                    "Invalid status. Use New, Acknowledged, Closed, or Open");
            }

            var isOpenQueue =
                string.Equals(statusFilter, "Open", StringComparison.OrdinalIgnoreCase)
                || string.Equals(statusFilter, DeliveryIssueStatuses.New, StringComparison.OrdinalIgnoreCase)
                || string.Equals(statusFilter, DeliveryIssueStatuses.Acknowledged, StringComparison.OrdinalIgnoreCase)
                || (string.IsNullOrWhiteSpace(statusFilter) && !includeClosed);

            // Open queue: all New/Acknowledged for the store, regardless of report date.
            // Closed / historical: apply date range (default last 7 days when omitted).
            var dateFilterApplied = !isOpenQueue;
            DateTime? fromUtc = null;
            DateTime? toUtc = null;
            if (dateFilterApplied)
            {
                (fromUtc, toUtc) = NormalizeRange(from, to, defaultDays: 7);
            }

            var qset = _unitOfWork.Context.Set<DeliveryIssueReport>()
                .AsNoTracking()
                .Include(r => r.Order!).ThenInclude(o => o.Batch)
                .Include(r => r.Rider)
                .Include(r => r.AcknowledgedByUser)
                .Include(r => r.ClosedByUser)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(scoped.storeId))
                qset = qset.Where(r => r.Order != null && r.Order.Batch != null
                    && r.Order.Batch.StoreId == scoped.storeId);

            if (fromUtc.HasValue)
                qset = qset.Where(r => r.CreatedAt >= fromUtc.Value);
            if (toUtc.HasValue)
                qset = qset.Where(r => r.CreatedAt < toUtc.Value);

            if (isOpenQueue
                || string.Equals(statusFilter, "Open", StringComparison.OrdinalIgnoreCase)
                || (string.IsNullOrWhiteSpace(statusFilter) && !includeClosed))
            {
                if (string.Equals(statusFilter, DeliveryIssueStatuses.New, StringComparison.OrdinalIgnoreCase))
                    qset = qset.Where(r => r.Status == DeliveryIssueStatuses.New);
                else if (string.Equals(statusFilter, DeliveryIssueStatuses.Acknowledged, StringComparison.OrdinalIgnoreCase))
                    qset = qset.Where(r => r.Status == DeliveryIssueStatuses.Acknowledged);
                else
                    qset = qset.Where(r => r.Status == DeliveryIssueStatuses.New
                        || r.Status == DeliveryIssueStatuses.Acknowledged);
            }
            else if (!string.IsNullOrWhiteSpace(statusFilter))
            {
                var normalized = DeliveryIssueStatuses.Normalize(statusFilter);
                qset = qset.Where(r => r.Status == normalized);
            }

            if (!string.IsNullOrWhiteSpace(q))
            {
                var term = q.Trim();
                qset = qset.Where(r =>
                    (r.Order != null && (r.Order.OrderId.Contains(term) || r.Order.OrderNo.Contains(term)))
                    || (r.Rider != null && (
                        (r.Rider.UserName != null && r.Rider.UserName.Contains(term))
                        || (r.Rider.ThirdPartyEmployeeId != null && r.Rider.ThirdPartyEmployeeId.Contains(term))))
                    || (r.ReasonCode != null && r.ReasonCode.Contains(term))
                    || (r.Note != null && r.Note.Contains(term))
                    || (r.InternalNote != null && r.InternalNote.Contains(term)));
            }

            var ordered = qset
                .OrderBy(r => r.Status == DeliveryIssueStatuses.New ? 0
                    : r.Status == DeliveryIssueStatuses.Acknowledged ? 1 : 2)
                .ThenByDescending(r => r.CreatedAt);

            var totalCount = await ordered.CountAsync();
            var rows = await ordered
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var list = rows.Select(MapIssueReportDto).ToList();
            return Ok(new AdminDeliveryIssueReportPageDto
            {
                items = list,
                page = page,
                pageSize = pageSize,
                totalCount = totalCount,
                hasMore = page * pageSize < totalCount,
                dateFilterApplied = dateFilterApplied
            }, "Delivery issue reports");
        }

        public async Task<ApiResponse<AdminDeliveryIssueReportDto>> GetDeliveryIssueReportAsync(
            AdminActor actor, long id)
        {
            var report = await LoadIssueForAdminAsync(id);
            if (report == null || !CanSeeStore(actor, report.Order?.Batch?.StoreId))
                return Fail<AdminDeliveryIssueReportDto>("Issue report not found");

            var dto = MapIssueReportDto(report);
            dto.history = await LoadIssueHistoryAsync(id);
            return Ok(dto, "Success");
        }

        public async Task<ApiResponse<AdminDeliveryIssueReportDto>> AcknowledgeDeliveryIssueAsync(
            AdminActor actor, long id, DeliveryIssueTriageRequest request)
            => await ApplyTriageAsync(actor, id, request, DeliveryIssueTriageActions.Acknowledged);

        public async Task<ApiResponse<AdminDeliveryIssueReportDto>> UpdateDeliveryIssueNoteAsync(
            AdminActor actor, long id, DeliveryIssueTriageRequest request)
            => await ApplyTriageAsync(actor, id, request, DeliveryIssueTriageActions.NoteUpdated);

        public async Task<ApiResponse<AdminDeliveryIssueReportDto>> CloseDeliveryIssueAsync(
            AdminActor actor, long id, DeliveryIssueTriageRequest request)
            => await ApplyTriageAsync(actor, id, request, DeliveryIssueTriageActions.Closed);

        private async Task<ApiResponse<AdminDeliveryIssueReportDto>> ApplyTriageAsync(
            AdminActor actor, long id, DeliveryIssueTriageRequest request, string action)
        {
            request ??= new DeliveryIssueTriageRequest();
            if (string.IsNullOrWhiteSpace(request.rowVersion))
                return Fail<AdminDeliveryIssueReportDto>("rowVersion is required");

            byte[] expectedVersion;
            try
            {
                expectedVersion = Convert.FromBase64String(request.rowVersion.Trim());
            }
            catch
            {
                return Fail<AdminDeliveryIssueReportDto>("Invalid rowVersion");
            }

            var note = string.IsNullOrWhiteSpace(request.internalNote) ? null : request.internalNote.Trim();
            if (note != null && note.Length > 1000)
                note = note[..1000];

            if (action == DeliveryIssueTriageActions.NoteUpdated && string.IsNullOrWhiteSpace(note))
                return Fail<AdminDeliveryIssueReportDto>("internalNote is required when updating the note");

            await using var tx = await _unitOfWork.Context.Database.BeginTransactionAsync();
            try
            {
                var report = await _unitOfWork.Context.Set<DeliveryIssueReport>()
                    .Include(r => r.Order!).ThenInclude(o => o.Batch)
                    .Include(r => r.Rider)
                    .FirstOrDefaultAsync(r => r.Id == id);

                if (report == null || !CanSeeStore(actor, report.Order?.Batch?.StoreId))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminDeliveryIssueReportDto>("Issue report not found");
                }

                // Snapshot delivery fields — triage must never mutate them.
                var order = report.Order!;
                var statusBefore = order.Status;
                var cashBefore = order.CashCollected;
                var handedBefore = order.CashHandedOverAmount;
                var handedAtBefore = order.CashHandedOverAt;

                if (report.RowVersion != null
                    && !report.RowVersion.SequenceEqual(expectedVersion))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminDeliveryIssueReportDto>(
                        "Issue was updated by another admin; refresh and try again");
                }

                // For SQL Server, set original concurrency token from client.
                _unitOfWork.Context.Entry(report).Property(r => r.RowVersion).OriginalValue = expectedVersion;

                var previous = report.Status ?? DeliveryIssueStatuses.New;
                var now = DateTime.UtcNow;
                string newStatus = previous;
                string historyAction = action;

                if (action == DeliveryIssueTriageActions.Acknowledged)
                {
                    if (!DeliveryIssueStatuses.CanAcknowledge(previous))
                    {
                        await tx.RollbackAsync();
                        return Fail<AdminDeliveryIssueReportDto>(
                            previous == DeliveryIssueStatuses.Acknowledged
                                ? "Issue is already acknowledged"
                                : "Only New issues can be acknowledged");
                    }
                    newStatus = DeliveryIssueStatuses.Acknowledged;
                    report.AcknowledgedAt = now;
                    report.AcknowledgedByUserId = actor.UserId;
                }
                else if (action == DeliveryIssueTriageActions.Closed)
                {
                    if (!DeliveryIssueStatuses.CanClose(previous))
                    {
                        await tx.RollbackAsync();
                        return Fail<AdminDeliveryIssueReportDto>(
                            previous == DeliveryIssueStatuses.Closed
                                ? "Issue is already closed"
                                : "Acknowledge the issue before closing it");
                    }
                    newStatus = DeliveryIssueStatuses.Closed;
                    report.ClosedAt = now;
                    report.ClosedByUserId = actor.UserId;
                }
                else if (action == DeliveryIssueTriageActions.NoteUpdated)
                {
                    if (!DeliveryIssueStatuses.CanUpdateNote(previous))
                    {
                        await tx.RollbackAsync();
                        return Fail<AdminDeliveryIssueReportDto>("Cannot update notes on a closed issue");
                    }
                    newStatus = previous;
                }
                else
                {
                    await tx.RollbackAsync();
                    return Fail<AdminDeliveryIssueReportDto>("Unsupported triage action");
                }

                if (note != null)
                    report.InternalNote = note;

                report.Status = newStatus;
                report.UpdatedAt = now;
                if (!string.Equals(
                        _unitOfWork.Context.Database.ProviderName,
                        "Microsoft.EntityFrameworkCore.SqlServer",
                        StringComparison.Ordinal))
                    report.RowVersion = Guid.NewGuid().ToByteArray();

                await _unitOfWork.Context.Set<DeliveryIssueTriageEvent>().AddAsync(new DeliveryIssueTriageEvent
                {
                    DeliveryIssueReportId = report.Id,
                    ActorUserId = actor.UserId,
                    ActorType = actor.IsHeadOffice ? "Administrator" : "Manager",
                    Action = historyAction,
                    PreviousStatus = previous,
                    NewStatus = newStatus,
                    InternalNote = note,
                    CreatedAt = now
                });

                try
                {
                    await _unitOfWork.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminDeliveryIssueReportDto>(
                        "Issue was updated by another admin; refresh and try again");
                }

                if (order.Status != statusBefore
                    || order.CashCollected != cashBefore
                    || order.CashHandedOverAmount != handedBefore
                    || order.CashHandedOverAt != handedAtBefore)
                {
                    await tx.RollbackAsync();
                    _logger.LogError("Triage unexpectedly mutated order {OrderId}", order.Id);
                    return Fail<AdminDeliveryIssueReportDto>("Unable to update issue");
                }

                await tx.CommitAsync();

                var fresh = await LoadIssueForAdminAsync(id);
                var dto = MapIssueReportDto(fresh!);
                dto.history = await LoadIssueHistoryAsync(id);
                return Ok(dto, action == DeliveryIssueTriageActions.Closed
                    ? "Issue closed"
                    : action == DeliveryIssueTriageActions.Acknowledged
                        ? "Issue acknowledged"
                        : "Internal note saved");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Triage failed for issue {IssueId}", id);
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminDeliveryIssueReportDto>("Unable to update issue");
            }
        }

        private async Task<DeliveryIssueReport?> LoadIssueForAdminAsync(long id)
        {
            return await _unitOfWork.Context.Set<DeliveryIssueReport>()
                .AsNoTracking()
                .Include(r => r.Order!).ThenInclude(o => o.Batch)
                .Include(r => r.Rider)
                .Include(r => r.AcknowledgedByUser)
                .Include(r => r.ClosedByUser)
                .FirstOrDefaultAsync(r => r.Id == id);
        }

        private async Task<List<AdminDeliveryIssueTriageEventDto>> LoadIssueHistoryAsync(long reportId)
        {
            var events = await _unitOfWork.Context.Set<DeliveryIssueTriageEvent>()
                .AsNoTracking()
                .Include(e => e.Actor)
                .Where(e => e.DeliveryIssueReportId == reportId)
                .OrderBy(e => e.CreatedAt)
                .ThenBy(e => e.Id)
                .ToListAsync();

            return events.Select(e => new AdminDeliveryIssueTriageEventDto
            {
                id = e.Id,
                action = e.Action,
                previousStatus = e.PreviousStatus,
                newStatus = e.NewStatus,
                actorType = e.ActorType,
                actorUserId = e.ActorUserId,
                actorName = e.Actor?.UserName,
                actorWorkerId = e.Actor?.ThirdPartyEmployeeId,
                internalNote = e.InternalNote,
                at = e.CreatedAt
            }).ToList();
        }

        public async Task<ApiResponse<AdminOrderDetailDto>> GetOrderAsync(AdminActor actor, long id)
        {
            var order = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
            if (order == null || !CanSeeStore(actor, order.Batch?.StoreId))
                return Fail<AdminOrderDetailDto>("Order not found");

            var dto = MapOrderDetail(order);
            var audits = await _unitOfWork.Context.Set<OrderLifecycleAudit>()
                .AsNoTracking()
                .Where(a => a.AssignedOrderId == id)
                .OrderBy(a => a.CreatedAt)
                .ThenBy(a => a.Id)
                .ToListAsync();

            dto.statusHistory = audits.Select(a => new AdminOrderLifecycleEventDto
            {
                status = a.NewStatus,
                previousStatus = a.PreviousStatus,
                actorType = a.ActorType,
                reason = a.Reason,
                at = a.CreatedAt
            }).ToList();

            var issues = await _unitOfWork.Context.Set<DeliveryIssueReport>()
                .AsNoTracking()
                .Include(r => r.Rider)
                .Include(r => r.Order!).ThenInclude(o => o.Batch)
                .Include(r => r.AcknowledgedByUser)
                .Include(r => r.ClosedByUser)
                .Where(r => r.AssignedOrderId == id)
                .OrderByDescending(r => r.CreatedAt)
                .ThenByDescending(r => r.Id)
                .ToListAsync();

            dto.issueReports = issues.Select(r =>
            {
                var mapped = MapIssueReportDto(r);
                mapped.orderStatus = order.Status;
                mapped.storeId = order.Batch?.StoreId;
                mapped.orderId = order.OrderId;
                mapped.orderNo = order.OrderNo;
                return mapped;
            }).ToList();

            return Ok(dto, "Success");
        }

        public async Task<ApiResponse<AdminOrderDetailDto>> CancelOrderAsync(AdminActor actor, long id, string reason)
        {
            if (string.IsNullOrWhiteSpace(reason))
                return Fail<AdminOrderDetailDto>("Cancel reason is required");

            var order = await _unitOfWork.AssignedOrderRepository.GetByIdForUpdateAsync(id);
            if (order == null || !CanSeeStore(actor, order.Batch?.StoreId))
                return Fail<AdminOrderDetailDto>("Order not found");

            if (order.Status is OrderStatuses.Completed)
                return Fail<AdminOrderDetailDto>("Completed orders cannot be cancelled");

            if (!OrderStatuses.CanAdminCancel(order.Status, order.FailureRequestStatus))
            {
                if (string.Equals(order.FailureRequestStatus, FailureRequestStatuses.Pending, StringComparison.OrdinalIgnoreCase))
                    return Fail<AdminOrderDetailDto>(
                        "Resolve or reject the pending failure request before cancelling");
                if (order.Status is OrderStatuses.ReturningToStore or OrderStatuses.AwaitingStoreReceipt)
                    return Fail<AdminOrderDetailDto>(
                        "Confirm store receipt before cancelling (or wait until Failed)");
                return Fail<AdminOrderDetailDto>("Order cannot be cancelled in its current state");
            }

            // Capture before mutate — used only if SaveChanges commits.
            var previous = order.Status;
            var assignedRiderId = order.AcceptedByUserId;
            var notifyRider = assignedRiderId.HasValue
                && OrderStatuses.IsActiveStatus(previous);
            var storeId = order.Batch?.StoreId;
            var externalOrderId = order.OrderId;
            var reasonTrimmed = reason.Trim();

            order.Status = OrderStatuses.Cancelled;
            order.CancelReason = reasonTrimmed;
            order.UpdatedAt = DateTime.UtcNow;

            await _unitOfWork.Context.Set<OrderLifecycleAudit>().AddAsync(new OrderLifecycleAudit
            {
                AssignedOrderId = id,
                ActorUserId = actor.UserId,
                ActorType = "Admin",
                PreviousStatus = previous,
                NewStatus = OrderStatuses.Cancelled,
                Reason = reasonTrimmed,
                CreatedAt = DateTime.UtcNow
            });

            await _unitOfWork.AssignedOrderRepository.UpdateAsync(order);

            try
            {
                await _unitOfWork.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                // Pickup (or another writer) committed first — do not notify/publish.
                _unitOfWork.Context.ChangeTracker.Clear();
                return await CancelConflictFromCommittedStateAsync(actor, id);
            }

            try
            {
                await _opsEvents.PublishOrderChangedAsync(storeId, id, externalOrderId, OrderStatuses.Cancelled);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ops publish after cancel failed");
            }

            // Notify only the assigned rider (not the whole store). Skip if cancel
            // applied to an unassigned Available order, or if previous state was not active.
            if (notifyRider)
            {
                try
                {
                    await _riderNotifications.NotifyOrderCancelledAsync(
                        assignedRiderId!.Value,
                        externalOrderId,
                        id,
                        reasonTrimmed);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Rider cancel notification failed for order {OrderId}", externalOrderId);
                }
            }

            var fresh = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
            return Ok(MapOrderDetail(fresh), "Order cancelled");
        }

        /// <summary>
        /// Maps the committed row after a lost cancel race into a business failure.
        /// Never treats the lost attempt as cancelled.
        /// </summary>
        private async Task<ApiResponse<AdminOrderDetailDto>> CancelConflictFromCommittedStateAsync(
            AdminActor actor, long id)
        {
            var current = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
            if (current == null || !CanSeeStore(actor, current.Batch?.StoreId))
                return Fail<AdminOrderDetailDto>("Order not found");

            if (current.Status == OrderStatuses.Cancelled)
                return Fail<AdminOrderDetailDto>("Order was already cancelled");

            if (current.Status == OrderStatuses.Completed)
                return Fail<AdminOrderDetailDto>("Completed orders cannot be cancelled");

            return Fail<AdminOrderDetailDto>(
                $"Order was updated concurrently (now {current.Status}); refresh and try again");
        }

        public async Task<ApiResponse<AdminOrderDetailDto>> RequeueOrderAsync(AdminActor actor, long id)
        {
            await using var tx = await _unitOfWork.Context.Database.BeginTransactionAsync();
            try
            {
                var order = await _unitOfWork.AssignedOrderRepository.GetByIdForUpdateAsync(id);
                if (order == null || !CanSeeStore(actor, order.Batch?.StoreId))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Order not found");
                }

                if (!OrderStatuses.CanAdminRequeue(order.Status))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Only Available, Cancelled, or Failed orders can be requeued");
                }

                // Under row lock — concurrent handover cannot sneak past this check.
                // Any prior CashCollected > 0 blocks Failed→Requeue (handover does not unlock).
                if (CashSemantics.BlocksFailedRequeue(
                        order.Status, order.CashCollected, order.CashHandedOverAmount))
                {
                    var collected = order.CashCollected!.Value;
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>(
                        $"Cannot requeue: this Failed order has {collected:0.00} cash collected. " +
                        "Requeue is blocked even after COD handover so a later rider cannot inherit " +
                        "or overwrite another rider's cash fields. Cancel the order instead, or wait " +
                        "for a per-rider cash ledger. Cash amounts are preserved.");
                }

                var previous = order.Status;
                var cashCollectedBefore = order.CashCollected;
                var handedBefore = order.CashHandedOverAmount;
                order.Status = OrderStatuses.Available;
                order.AcceptedByUserId = null;
                order.AcceptedAt = null;
                order.PickedUpAt = null;
                order.CompletedAt = null;
                order.IsDirectAssignment = false;
                order.CancelReason = null;
                // Preserve COD expected / collected / handover — never zero on requeue.
                OrderService.ClearFailureFields(order);
                order.UpdatedAt = DateTime.UtcNow;

                var rejections = await _unitOfWork.Context.Set<OrderRejection>()
                    .Where(r => r.AssignedOrderId == id)
                    .ToListAsync();
                _unitOfWork.Context.Set<OrderRejection>().RemoveRange(rejections);

                await _unitOfWork.Context.Set<OrderLifecycleAudit>().AddAsync(new OrderLifecycleAudit
                {
                    AssignedOrderId = id,
                    ActorUserId = actor.UserId,
                    ActorType = "Admin",
                    PreviousStatus = previous,
                    NewStatus = OrderStatuses.Available,
                    Reason = "Requeued",
                    CashCollected = cashCollectedBefore,
                    CreatedAt = DateTime.UtcNow
                });

                await _unitOfWork.AssignedOrderRepository.UpdateAsync(order);

                try
                {
                    await _unitOfWork.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    await tx.RollbackAsync();
                    _unitOfWork.Context.ChangeTracker.Clear();
                    return Fail<AdminOrderDetailDto>(
                        "Order changed concurrently (e.g. cash handover); refresh and try again");
                }

                // Defensive: cash amounts must never be zeroed by requeue.
                if (order.CashCollected != cashCollectedBefore
                    || order.CashHandedOverAmount != handedBefore)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Unable to requeue without changing COD amounts");
                }

                await tx.CommitAsync();

                try
                {
                    await _opsEvents.PublishOrderChangedAsync(
                        order.Batch?.StoreId, id, order.OrderId, OrderStatuses.Available);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ops publish after requeue failed");
                }

                var fresh = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
                return Ok(MapOrderDetail(fresh), "Order requeued as Available");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Requeue failed for order {OrderId}", id);
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Unable to requeue order");
            }
        }

        public async Task<ApiResponse<AdminOrderDetailDto>> RejectFailureRequestAsync(
            AdminActor actor, long id, FailureDecisionRequest request)
        {
            request ??= new FailureDecisionRequest();
            var note = string.IsNullOrWhiteSpace(request.note) ? null : request.note.Trim();
            if (note != null && note.Length > 500)
                note = note[..500];

            await using var tx = await _unitOfWork.Context.Database.BeginTransactionAsync();
            try
            {
                var order = await _unitOfWork.AssignedOrderRepository.GetByIdForUpdateAsync(id);
                if (order == null || !CanSeeStore(actor, order.Batch?.StoreId))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Order not found");
                }

                if (!string.Equals(order.FailureRequestStatus, FailureRequestStatuses.Pending, StringComparison.OrdinalIgnoreCase))
                {
                    await tx.RollbackAsync();
                    if (string.Equals(order.FailureRequestStatus, FailureRequestStatuses.Rejected, StringComparison.OrdinalIgnoreCase))
                        return Ok(MapOrderDetail(order), "Failure request already rejected");
                    return Fail<AdminOrderDetailDto>("No pending failure request to reject");
                }

                if (OrderStatuses.IsFailedDeliveryFlowStatus(order.Status) || order.Status == OrderStatuses.Failed)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Return already in progress; cannot reject");
                }

                if (order.Status is OrderStatuses.Completed or OrderStatuses.Cancelled)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>($"Order is already {order.Status}");
                }

                var previous = order.Status;
                var now = DateTime.UtcNow;
                order.FailureRequestStatus = FailureRequestStatuses.Rejected;
                order.FailureDecidedAt = now;
                order.FailureDecidedByUserId = actor.UserId;
                order.FailureDecisionNote = note ?? "Rejected — continue delivery";
                order.UpdatedAt = now;
                // Status unchanged — rider continues delivery. COD untouched.

                await _unitOfWork.Context.Set<OrderLifecycleAudit>().AddAsync(new OrderLifecycleAudit
                {
                    AssignedOrderId = id,
                    ActorUserId = actor.UserId,
                    ActorType = "Admin",
                    PreviousStatus = previous,
                    NewStatus = previous,
                    Reason = "FailureRejected" + (note != null ? $": {note}" : ""),
                    RequestId = string.IsNullOrWhiteSpace(request.requestId) ? null : request.requestId.Trim(),
                    CreatedAt = now
                });

                await _unitOfWork.AssignedOrderRepository.UpdateAsync(order);
                await _unitOfWork.SaveChangesAsync();
                await tx.CommitAsync();

                try
                {
                    await _opsEvents.PublishOrderChangedAsync(
                        order.Batch?.StoreId, id, order.OrderId, order.Status);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ops publish after failure reject failed");
                }

                var fresh = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
                return Ok(MapOrderDetail(fresh), "Failure request rejected — rider continues delivery");
            }
            catch (DbUpdateConcurrencyException)
            {
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Order changed concurrently; refresh and try again");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Reject failure request failed for order {OrderId}", id);
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Unable to reject failure request");
            }
        }

        public async Task<ApiResponse<AdminOrderDetailDto>> ApproveFailureReturnAsync(
            AdminActor actor, long id, FailureDecisionRequest request)
        {
            request ??= new FailureDecisionRequest();
            var note = string.IsNullOrWhiteSpace(request.note) ? null : request.note.Trim();
            if (note != null && note.Length > 500)
                note = note[..500];

            await using var tx = await _unitOfWork.Context.Database.BeginTransactionAsync();
            try
            {
                var order = await _unitOfWork.AssignedOrderRepository.GetByIdForUpdateAsync(id);
                if (order == null || !CanSeeStore(actor, order.Batch?.StoreId))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Order not found");
                }

                if (order.Status == OrderStatuses.ReturningToStore
                    && string.Equals(
                        order.FailureRequestStatus,
                        FailureRequestStatuses.ReturnApproved,
                        StringComparison.OrdinalIgnoreCase))
                {
                    await tx.CommitAsync();
                    return Ok(MapOrderDetail(order), "Return already approved");
                }

                if (!string.Equals(order.FailureRequestStatus, FailureRequestStatuses.Pending, StringComparison.OrdinalIgnoreCase))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("No pending failure request to approve");
                }

                if (!OrderStatuses.IsActiveStatus(order.Status)
                    || OrderStatuses.IsFailedDeliveryFlowStatus(order.Status)
                    || order.Status is OrderStatuses.Completed or OrderStatuses.Cancelled or OrderStatuses.Failed)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>(
                        order.Status is OrderStatuses.Completed or OrderStatuses.Cancelled
                            ? $"Order is already {order.Status}"
                            : "Order is not eligible for return approval");
                }

                var previous = order.Status;
                var now = DateTime.UtcNow;
                order.StatusBeforeReturn = previous;
                order.Status = OrderStatuses.ReturningToStore;
                order.FailureRequestStatus = FailureRequestStatuses.ReturnApproved;
                order.FailureDecidedAt = now;
                order.FailureDecidedByUserId = actor.UserId;
                order.FailureDecisionNote = note ?? "Return to store approved";
                order.UpdatedAt = now;
                // Approval instructs return — does not claim already returned. COD untouched.

                await _unitOfWork.Context.Set<OrderLifecycleAudit>().AddAsync(new OrderLifecycleAudit
                {
                    AssignedOrderId = id,
                    ActorUserId = actor.UserId,
                    ActorType = "Admin",
                    PreviousStatus = previous,
                    NewStatus = OrderStatuses.ReturningToStore,
                    Reason = "FailureReturnApproved" + (note != null ? $": {note}" : ""),
                    RequestId = string.IsNullOrWhiteSpace(request.requestId) ? null : request.requestId.Trim(),
                    CreatedAt = now
                });

                await _unitOfWork.AssignedOrderRepository.UpdateAsync(order);
                await _unitOfWork.SaveChangesAsync();
                await tx.CommitAsync();

                try
                {
                    await _opsEvents.PublishOrderChangedAsync(
                        order.Batch?.StoreId, id, order.OrderId, OrderStatuses.ReturningToStore);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ops publish after return approve failed");
                }

                var fresh = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
                return Ok(MapOrderDetail(fresh), "Return to store approved — rider must confirm arrival");
            }
            catch (DbUpdateConcurrencyException)
            {
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Order changed concurrently; refresh and try again");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Approve failure return failed for order {OrderId}", id);
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Unable to approve return");
            }
        }

        public async Task<ApiResponse<AdminOrderDetailDto>> ConfirmStoreReceiptAsync(
            AdminActor actor, long id, FailureDecisionRequest request)
        {
            request ??= new FailureDecisionRequest();
            var note = string.IsNullOrWhiteSpace(request.note) ? null : request.note.Trim();
            if (note != null && note.Length > 500)
                note = note[..500];

            await using var tx = await _unitOfWork.Context.Database.BeginTransactionAsync();
            try
            {
                var order = await _unitOfWork.AssignedOrderRepository.GetByIdForUpdateAsync(id);
                if (order == null || !CanSeeStore(actor, order.Batch?.StoreId))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Order not found");
                }

                if (order.Status == OrderStatuses.Failed
                    && string.Equals(
                        order.FailureRequestStatus,
                        FailureRequestStatuses.StoreReceived,
                        StringComparison.OrdinalIgnoreCase))
                {
                    await tx.CommitAsync();
                    return Ok(MapOrderDetail(order), "Store receipt already confirmed");
                }

                if (order.Status != OrderStatuses.AwaitingStoreReceipt
                    || !string.Equals(
                        order.FailureRequestStatus,
                        FailureRequestStatuses.RiderReturned,
                        StringComparison.OrdinalIgnoreCase))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>(
                        "Rider must confirm return before store receipt can be recorded");
                }

                var previous = order.Status;
                var now = DateTime.UtcNow;
                order.Status = OrderStatuses.Failed;
                order.FailureRequestStatus = FailureRequestStatuses.StoreReceived;
                order.StoreReceivedAt = now;
                order.StoreReceivedByUserId = actor.UserId;
                if (note != null)
                    order.FailureDecisionNote = note;
                order.UpdatedAt = now;
                // COD preserved — if cash collected, manager must use cash handover.

                await _unitOfWork.Context.Set<OrderLifecycleAudit>().AddAsync(new OrderLifecycleAudit
                {
                    AssignedOrderId = id,
                    ActorUserId = actor.UserId,
                    ActorType = "Admin",
                    PreviousStatus = previous,
                    NewStatus = OrderStatuses.Failed,
                    Reason = "StoreReceiptConfirmed" + (note != null ? $": {note}" : ""),
                    RequestId = string.IsNullOrWhiteSpace(request.requestId) ? null : request.requestId.Trim(),
                    CashCollected = order.CashCollected,
                    CreatedAt = now
                });

                await _unitOfWork.AssignedOrderRepository.UpdateAsync(order);
                await _unitOfWork.SaveChangesAsync();
                await tx.CommitAsync();

                try
                {
                    await _opsEvents.PublishOrderChangedAsync(
                        order.Batch?.StoreId, id, order.OrderId, OrderStatuses.Failed);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ops publish after store receipt failed");
                }

                var fresh = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
                return Ok(MapOrderDetail(fresh), "Store receipt confirmed — order is Failed; cancel or requeue when ready");
            }
            catch (DbUpdateConcurrencyException)
            {
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Order changed concurrently; refresh and try again");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Confirm store receipt failed for order {OrderId}", id);
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Unable to confirm store receipt");
            }
        }

        public async Task<ApiResponse<AdminOrderDetailDto>> SetCashCollectedAsync(AdminActor actor, long id, decimal? cashCollected)
        {
            await using var tx = await _unitOfWork.Context.Database.BeginTransactionAsync();
            try
            {
                var order = await _unitOfWork.AssignedOrderRepository.GetByIdForUpdateAsync(id);
                if (order == null || !CanSeeStore(actor, order.Batch?.StoreId))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Order not found");
                }

                if (cashCollected.HasValue && cashCollected.Value < 0)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Cash collected cannot be negative");
                }

                var handed = order.CashHandedOverAmount ?? 0m;
                if (!cashCollected.HasValue && handed > 0)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>(
                        "Cannot clear cash collected after cash has been handed over");
                }
                if (cashCollected.HasValue && cashCollected.Value < handed)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>(
                        $"Cash collected cannot be below amount already handed over ({handed:0.00})");
                }

                order.CashCollected = cashCollected;
                order.CashSemanticsNote = CashSemantics.AdminCorrected;
                order.UpdatedAt = DateTime.UtcNow;

                await _unitOfWork.Context.Set<OrderLifecycleAudit>().AddAsync(new OrderLifecycleAudit
                {
                    AssignedOrderId = id,
                    ActorUserId = actor.UserId,
                    ActorType = "Admin",
                    PreviousStatus = order.Status,
                    NewStatus = order.Status,
                    Reason = "AdminCashCorrection",
                    CashCollected = cashCollected,
                    CreatedAt = DateTime.UtcNow
                });

                await _unitOfWork.AssignedOrderRepository.UpdateAsync(order);
                await _unitOfWork.SaveChangesAsync();
                await tx.CommitAsync();

                var fresh = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
                return Ok(MapOrderDetail(fresh), "Cash collected updated");
            }
            catch (Exception)
            {
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Unable to update cash collected");
            }
        }

        public async Task<ApiResponse<AdminOrderDetailDto>> ConfirmCashHandoverAsync(
            AdminActor actor, long id, CashHandoverRequest request)
        {
            request ??= new CashHandoverRequest();
            var requestId = string.IsNullOrWhiteSpace(request.requestId) ? null : request.requestId.Trim();

            await using var tx = await _unitOfWork.Context.Database.BeginTransactionAsync();
            try
            {
                var order = await _unitOfWork.AssignedOrderRepository.GetByIdForUpdateAsync(id);
                if (order == null || !CanSeeStore(actor, order.Batch?.StoreId))
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Order not found");
                }

                if (!string.IsNullOrEmpty(requestId)
                    && string.Equals(order.HandoverRequestId, requestId, StringComparison.Ordinal))
                {
                    await tx.CommitAsync();
                    var same = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
                    return Ok(MapOrderDetail(same), "Cash handover confirmed");
                }

                if (string.Equals(order.CashSemanticsNote, CashSemantics.LegacyAmbiguous, StringComparison.OrdinalIgnoreCase)
                    && !order.CashCollected.HasValue)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Legacy cash record must be reconciled before handover");
                }

                if (!order.CashCollected.HasValue || order.CashCollected.Value <= 0)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("No collected cash available to hand over");
                }

                var alreadyHanded = order.CashHandedOverAmount ?? 0;
                var remaining = order.CashCollected.Value - alreadyHanded;
                if (remaining <= 0)
                {
                    await tx.RollbackAsync();
                    return Fail<AdminOrderDetailDto>("Collected cash has already been fully handed over");
                }

                decimal increment;
                if (request.amount == null)
                {
                    increment = remaining;
                }
                else
                {
                    if (request.amount.Value <= 0)
                    {
                        await tx.RollbackAsync();
                        return Fail<AdminOrderDetailDto>("Handover amount must be positive");
                    }
                    if (request.amount.Value > remaining)
                    {
                        await tx.RollbackAsync();
                        return Fail<AdminOrderDetailDto>(
                            $"Handover amount exceeds remaining collectible balance ({remaining:0.00})");
                    }
                    increment = request.amount.Value;
                }

                var previousHanded = alreadyHanded;
                order.CashHandedOverAmount = alreadyHanded + increment;
                order.CashHandedOverAt = DateTime.UtcNow;
                order.CashHandedOverByUserId = actor.UserId;
                order.CashSemanticsNote = CashSemantics.HandedOver;
                order.UpdatedAt = DateTime.UtcNow;
                if (!string.IsNullOrEmpty(requestId))
                    order.HandoverRequestId = requestId;

                await _unitOfWork.Context.Set<OrderLifecycleAudit>().AddAsync(new OrderLifecycleAudit
                {
                    AssignedOrderId = id,
                    ActorUserId = actor.UserId,
                    ActorType = "Admin",
                    PreviousStatus = order.Status,
                    NewStatus = order.Status,
                    Reason = string.IsNullOrWhiteSpace(request.reason)
                        ? $"CashHandover +{increment:0.00} (was {previousHanded:0.00})"
                        : request.reason.Trim(),
                    RequestId = requestId,
                    CashCollected = increment,
                    CreatedAt = DateTime.UtcNow
                });

                await _unitOfWork.AssignedOrderRepository.UpdateAsync(order);
                await _unitOfWork.SaveChangesAsync();
                await tx.CommitAsync();

                var fresh = await _unitOfWork.AssignedOrderRepository.GetByIdWithItemsAsync(id);
                return Ok(MapOrderDetail(fresh), "Cash handover confirmed");
            }
            catch (Exception)
            {
                try { await tx.RollbackAsync(); } catch { /* ignore */ }
                return Fail<AdminOrderDetailDto>("Unable to confirm cash handover");
            }
        }

        public async Task<ApiResponse<List<AdminNotificationDto>>> ListAdminNotificationsAsync(
            AdminActor actor, string storeId, int take)
        {
            var scoped = ScopeStore(actor, storeId);
            if (scoped.denied)
                return Fail<List<AdminNotificationDto>>(scoped.message);

            if (take < 1) take = 50;
            if (take > 200) take = 200;

            var q = _unitOfWork.Context.Set<AdminNotification>().AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(scoped.storeId))
                q = q.Where(n => n.StoreId == scoped.storeId || n.StoreId == null);
            else if (!actor.IsHeadOffice)
                q = q.Where(n => n.StoreId == actor.StoreId);

            var list = await q.OrderByDescending(n => n.CreatedAt).Take(take).ToListAsync();
            return Ok(list.Select(n => new AdminNotificationDto
            {
                id = n.Id,
                storeId = n.StoreId,
                category = n.Category,
                title = n.Title,
                body = n.Body,
                orderId = n.OrderId,
                assignedOrderId = n.AssignedOrderId,
                isRead = n.IsRead,
                createdAt = n.CreatedAt
            }).ToList(), "Notifications");
        }

        public async Task<ApiResponse<bool>> MarkAdminNotificationReadAsync(AdminActor actor, long id)
        {
            var n = await _unitOfWork.Context.Set<AdminNotification>().FirstOrDefaultAsync(x => x.Id == id);
            if (n == null || !CanSeeStore(actor, n.StoreId))
                return Fail<bool>("Notification not found");

            n.IsRead = true;
            await _unitOfWork.SaveChangesAsync();
            return Ok(true, "Marked read");
        }

        public async Task<ApiResponse<PaymentsDashboardDto>> GetPaymentsAsync(
            AdminActor actor, DateTime? from, DateTime? to, string storeId, Guid? riderId)
        {
            var scoped = ScopeStore(actor, storeId);
            if (scoped.denied)
                return Fail<PaymentsDashboardDto>(scoped.message);

            var (fromUtc, toUtc) = NormalizeRange(from, to, defaultDays: 7);
            var payout = await LoadPayoutAsync();
            var orders = await _unitOfWork.AssignedOrderRepository
                .QueryForAdminAsync(scoped.storeId, null, riderId, fromUtc, toUtc);

            return Ok(BuildPayments(orders, fromUtc.Value, toUtc.Value, scoped.storeId, payout), "Payments");
        }

        public async Task<ApiResponse<byte[]>> ExportPaymentsAsync(
            AdminActor actor, DateTime? from, DateTime? to, string storeId, Guid? riderId, string format)
        {
            var result = await GetPaymentsAsync(actor, from, to, storeId, riderId);
            if (!result.status || result.Data == null)
                return Fail<byte[]>(result.message ?? "Nothing to export");

            var dash = result.Data;
            var rows = new List<string[]>
            {
                new[] { "WorkerId", "Name", "Store", "Deliveries", "Cancelled", "Sales", "CashHeld", "PayoutDue" }
            };
            foreach (var r in dash.byRider)
            {
                rows.Add(new[]
                {
                    r.workerId,
                    r.name,
                    r.storeId,
                    r.deliveryCount.ToString(CultureInfo.InvariantCulture),
                    r.cancelledCount.ToString(CultureInfo.InvariantCulture),
                    r.salesTotal.ToString("0.00", CultureInfo.InvariantCulture),
                    r.cashHeld.ToString("0.00", CultureInfo.InvariantCulture),
                    r.payoutDue.ToString("0.00", CultureInfo.InvariantCulture)
                });
            }

            var excel = string.Equals(format, "xlsx", StringComparison.OrdinalIgnoreCase)
                        || string.Equals(format, "xls", StringComparison.OrdinalIgnoreCase);
            var bytes = excel ? ToSpreadsheetMl(rows) : ToCsv(rows);
            return Ok(bytes, "Export");
        }

        public async Task<ApiResponse<ReportsDto>> GetReportsAsync(
            AdminActor actor, DateTime? from, DateTime? to, string storeId, Guid? riderId)
        {
            var scoped = ScopeStore(actor, storeId);
            if (scoped.denied)
                return Fail<ReportsDto>(scoped.message);

            var (fromUtc, toUtc) = NormalizeRange(from, to, defaultDays: 7);
            var orders = await _unitOfWork.AssignedOrderRepository
                .QueryForAdminAsync(scoped.storeId, null, riderId, fromUtc, toUtc);

            var timed = orders
                .Where(o => o.AcceptedAt.HasValue && o.CompletedAt.HasValue && o.CompletedAt >= o.AcceptedAt)
                .ToList();

            var perRider = orders
                .Where(o => o.AcceptedByUserId.HasValue)
                .GroupBy(o => new
                {
                    Date = o.CreatedAt.Date.ToString("yyyy-MM-dd"),
                    RiderId = o.AcceptedByUserId.Value,
                    WorkerId = o.AcceptedByUser?.ThirdPartyEmployeeId ?? "",
                    Name = o.AcceptedByUser?.UserName ?? ""
                })
                .Select(g => new OrdersPerRiderDayDto
                {
                    date = g.Key.Date,
                    riderId = g.Key.RiderId,
                    workerId = g.Key.WorkerId,
                    name = g.Key.Name,
                    completed = g.Count(x => x.Status == "Completed"),
                    cancelled = g.Count(x => x.Status == "Cancelled"),
                    accepted = g.Count(x => x.Status == OrderStatuses.Accepted),
                    inProgress = g.Count(x =>
                        OrderStatuses.IsActiveStatus(x.Status) && x.Status != OrderStatuses.Accepted)
                })
                .OrderByDescending(x => x.date)
                .ThenBy(x => x.workerId)
                .ToList();

            var dto = new ReportsDto
            {
                status = new StatusSummaryDto
                {
                    available = orders.Count(o => o.Status == OrderStatuses.Available),
                    accepted = orders.Count(o => o.Status == OrderStatuses.Accepted),
                    inProgress = orders.Count(o =>
                        OrderStatuses.IsActiveStatus(o.Status) && o.Status != OrderStatuses.Accepted),
                    completed = orders.Count(o => o.Status == OrderStatuses.Completed),
                    cancelled = orders.Count(o => o.Status == OrderStatuses.Cancelled),
                    total = orders.Count
                },
                avgDeliveryTime = new AvgDeliveryTimeDto
                {
                    sampleCount = timed.Count,
                    avgMinutes = timed.Count == 0
                        ? null
                        : timed.Average(o => (o.CompletedAt.Value - o.AcceptedAt.Value).TotalMinutes)
                },
                perRiderPerDay = perRider
            };

            return Ok(dto, "Reports");
        }

        public async Task<ApiResponse<List<StoreDto>>> ListStoresAsync(AdminActor actor)
        {
            var stores = await _unitOfWork.StoreRepository.ListActiveAsync();
            if (!actor.IsHeadOffice)
            {
                stores = stores
                    .Where(s => string.Equals(s.StoreId, actor.StoreId, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }

            return Ok(stores.Select(s => new StoreDto
            {
                storeId = s.StoreId,
                name = string.IsNullOrWhiteSpace(s.Name) ? s.StoreId : s.Name,
                isActive = s.IsActive
            }).ToList(), "Stores");
        }

        public async Task<ApiResponse<PayoutSettingsDto>> GetPayoutSettingsAsync(AdminActor actor)
            => Ok(await LoadPayoutAsync(), "Payout settings");

        public async Task<ApiResponse<PayoutSettingsDto>> UpdatePayoutSettingsAsync(AdminActor actor, PayoutSettingsDto request)
        {
            if (!actor.IsHeadOffice)
                return Fail<PayoutSettingsDto>("Only head office can change payout settings");

            request ??= new PayoutSettingsDto();
            var mode = string.Equals(request.mode, "percent", StringComparison.OrdinalIgnoreCase) ? "percent" : "fixed";
            if (request.fixedFee < 0 || request.percent < 0)
                return Fail<PayoutSettingsDto>("Payout values cannot be negative");

            await _unitOfWork.AppSettingRepository.SetValueAsync("PayoutMode", mode);
            await _unitOfWork.AppSettingRepository.SetValueAsync(
                "PayoutFixedFee", request.fixedFee.ToString(CultureInfo.InvariantCulture));
            await _unitOfWork.AppSettingRepository.SetValueAsync(
                "PayoutPercent", request.percent.ToString(CultureInfo.InvariantCulture));
            await _unitOfWork.SaveChangesAsync();

            return Ok(await LoadPayoutAsync(), "Payout settings saved");
        }

        private async Task<PayoutSettingsDto> LoadPayoutAsync()
        {
            var mode = await _unitOfWork.AppSettingRepository.GetValueAsync("PayoutMode", "fixed");
            var feeRaw = await _unitOfWork.AppSettingRepository.GetValueAsync("PayoutFixedFee", "50");
            var pctRaw = await _unitOfWork.AppSettingRepository.GetValueAsync("PayoutPercent", "10");
            decimal.TryParse(feeRaw, NumberStyles.Any, CultureInfo.InvariantCulture, out var fee);
            decimal.TryParse(pctRaw, NumberStyles.Any, CultureInfo.InvariantCulture, out var pct);
            return new PayoutSettingsDto
            {
                mode = string.Equals(mode, "percent", StringComparison.OrdinalIgnoreCase) ? "percent" : "fixed",
                fixedFee = fee,
                percent = pct
            };
        }

        private PaymentsDashboardDto BuildPayments(
            List<AssignedOrder> orders, DateTime fromUtc, DateTime toUtc, string storeId, PayoutSettingsDto payout)
        {
            var completed = orders.Where(o => o.Status == "Completed").ToList();

            decimal Bucket(AssignedOrder o) => IsCash(o.PaymentMethod) ? (o.Cash ?? o.OrderTotal) : o.OrderTotal;

            var cash = completed.Where(o => IsCash(o.PaymentMethod)).Sum(Bucket);
            var card = completed.Where(o => IsCard(o.PaymentMethod)).Sum(o => o.OrderTotal);
            var other = completed.Where(o => !IsCash(o.PaymentMethod) && !IsCard(o.PaymentMethod)).Sum(o => o.OrderTotal);

            var cashToCollect = orders.Where(o => IsCash(o.PaymentMethod) && o.Status != "Cancelled")
                .Sum(ExpectedCashDue);
            var cashCollected = orders.Sum(o => o.CashCollected ?? 0);

            var byDay = completed
                .GroupBy(o => (o.CompletedAt ?? o.CreatedAt).Date.ToString("yyyy-MM-dd"))
                .Select(g => new PaymentByDayDto
                {
                    date = g.Key,
                    orderCount = g.Count(),
                    total = g.Sum(x => x.OrderTotal),
                    cash = g.Where(x => IsCash(x.PaymentMethod)).Sum(Bucket),
                    card = g.Where(x => IsCard(x.PaymentMethod)).Sum(x => x.OrderTotal),
                    other = g.Where(x => !IsCash(x.PaymentMethod) && !IsCard(x.PaymentMethod)).Sum(x => x.OrderTotal)
                })
                .OrderBy(x => x.date)
                .ToList();

            var byStore = completed
                .GroupBy(o => o.Batch?.StoreId ?? "")
                .Select(g => new PaymentByStoreDto
                {
                    storeId = g.Key,
                    orderCount = g.Count(),
                    total = g.Sum(x => x.OrderTotal),
                    cash = g.Where(x => IsCash(x.PaymentMethod)).Sum(Bucket),
                    card = g.Where(x => IsCard(x.PaymentMethod)).Sum(x => x.OrderTotal),
                    other = g.Where(x => !IsCash(x.PaymentMethod) && !IsCard(x.PaymentMethod)).Sum(x => x.OrderTotal)
                })
                .OrderBy(x => x.storeId)
                .ToList();

            var byRider = orders
                .Where(o => o.AcceptedByUserId.HasValue)
                .GroupBy(o => new
                {
                    Id = o.AcceptedByUserId.Value,
                    WorkerId = o.AcceptedByUser?.ThirdPartyEmployeeId ?? "",
                    Name = o.AcceptedByUser?.UserName ?? "",
                    Store = o.AcceptedByUser?.StoreId ?? o.Batch?.StoreId ?? ""
                })
                .Select(g =>
                {
                    var done = g.Where(x => x.Status == "Completed").ToList();
                    var sales = done.Sum(x => x.OrderTotal);
                    var payoutDue = payout.mode == "percent"
                        ? Math.Round(sales * payout.percent / 100m, 2)
                        : done.Count * payout.fixedFee;

                    var cashHeld = g.Where(x => IsCash(x.PaymentMethod) && x.Status != "Cancelled")
                        .Sum(CashOutstandingToStore);

                    return new RiderSettlementDto
                    {
                        riderId = g.Key.Id,
                        workerId = g.Key.WorkerId,
                        name = g.Key.Name,
                        storeId = g.Key.Store,
                        deliveryCount = done.Count,
                        cancelledCount = g.Count(x => x.Status == "Cancelled"),
                        cashHeld = cashHeld,
                        payoutDue = payoutDue,
                        salesTotal = sales
                    };
                })
                .OrderBy(x => x.workerId)
                .ToList();

            return new PaymentsDashboardDto
            {
                from = fromUtc,
                to = toUtc,
                storeId = storeId,
                orderCount = completed.Count,
                totalSales = completed.Sum(o => o.OrderTotal),
                cashTotal = cash,
                cardTotal = card,
                otherTotal = other,
                cashToCollect = cashToCollect,
                cashCollected = cashCollected,
                byDay = byDay,
                byStore = byStore,
                byRider = byRider
            };
        }

        private async Task<Dictionary<string, string>> StoreLookupAsync()
        {
            var stores = await _unitOfWork.StoreRepository.ListActiveAsync();
            return stores.ToDictionary(
                s => s.StoreId,
                s => string.IsNullOrWhiteSpace(s.Name) ? s.StoreId : s.Name,
                StringComparer.OrdinalIgnoreCase);
        }

        private static AdminRiderDto MapRider(AppUser u, Dictionary<string, string> stores)
        {
            string storeName = null;
            if (!string.IsNullOrWhiteSpace(u.StoreId))
                stores.TryGetValue(u.StoreId, out storeName);

            return new AdminRiderDto
            {
                userId = u.UserId,
                workerId = u.ThirdPartyEmployeeId,
                name = u.UserName,
                email = u.Email,
                phone = u.PhoneNumber,
                storeId = u.StoreId,
                storeName = storeName ?? u.StoreId,
                isActive = u.IsActive,
                isVerified = u.IsVerified,
                isOnline = u.IsAvailableOnline
                    && u.LastSeenAt.HasValue
                    && u.LastSeenAt.Value >= DateTime.UtcNow - OnlineWindow,
                lastSeenAt = u.LastSeenAt,
                createdAt = u.CreatedAt,
                roles = RolesOf(u)
            };
        }

        private static AdminOrderListDto MapOrderList(AssignedOrder o) => new()
        {
            id = o.Id,
            orderId = o.OrderId,
            orderNo = o.OrderNo,
            storeId = o.Batch?.StoreId,
            status = o.Status,
            firstName = o.FirstName,
            lastName = o.LastName,
            phone = o.Phone,
            city = o.City,
            street = o.Street,
            addressNo = o.AddressNo,
            orderTotal = o.OrderTotal,
            paymentMethod = o.PaymentMethod,
            cash = o.Cash,
            cashCollected = o.CashCollected,
            expectedCash = o.ExpectedCash,
            cashHandedOverAmount = o.CashHandedOverAmount,
            cashHandedOverAt = o.CashHandedOverAt,
            cashSemanticsNote = o.CashSemanticsNote,
            isDirectAssignment = o.IsDirectAssignment,
            cancelReason = o.CancelReason,
            acceptedByUserId = o.AcceptedByUserId,
            acceptedByName = o.AcceptedByUser?.UserName,
            acceptedByWorkerId = o.AcceptedByUser?.ThirdPartyEmployeeId,
            createdAt = o.CreatedAt,
            acceptedAt = o.AcceptedAt,
            pickedUpAt = o.PickedUpAt,
            completedAt = o.CompletedAt,
            updatedAt = o.UpdatedAt
        };

        private static AdminOrderDetailDto MapOrderDetail(AssignedOrder o)
        {
            var dto = new AdminOrderDetailDto();
            var list = MapOrderList(o);
            dto.id = list.id;
            dto.orderId = list.orderId;
            dto.orderNo = list.orderNo;
            dto.storeId = list.storeId;
            dto.status = list.status;
            dto.firstName = list.firstName;
            dto.lastName = list.lastName;
            dto.phone = list.phone;
            dto.city = list.city;
            dto.street = list.street;
            dto.addressNo = list.addressNo;
            dto.orderTotal = list.orderTotal;
            dto.paymentMethod = list.paymentMethod;
            dto.cash = list.cash;
            dto.cashCollected = list.cashCollected;
            dto.expectedCash = list.expectedCash;
            dto.cashHandedOverAmount = list.cashHandedOverAmount;
            dto.cashHandedOverAt = list.cashHandedOverAt;
            dto.cashSemanticsNote = list.cashSemanticsNote;
            dto.isDirectAssignment = list.isDirectAssignment;
            dto.cancelReason = list.cancelReason;
            dto.acceptedByUserId = list.acceptedByUserId;
            dto.acceptedByName = list.acceptedByName;
            dto.acceptedByWorkerId = list.acceptedByWorkerId;
            dto.createdAt = list.createdAt;
            dto.acceptedAt = list.acceptedAt;
            dto.pickedUpAt = list.pickedUpAt;
            dto.completedAt = list.completedAt;
            dto.updatedAt = list.updatedAt;
            dto.orderTypeId = o.OrderTypeId;
            dto.orderState = o.OrderState;
            dto.comment = o.Comment;
            dto.postCode = o.PostCode;
            dto.secondaryAddress = o.SecondaryAddress;
            dto.lat = o.Lat;
            dto.lng = o.Lng;
            dto.orderTime = o.OrderTime;
            dto.batchTime = o.Batch?.Time;
            dto.failure = OrderService.MapFailure(o);
            dto.cashOutstandingToStore = CashOutstandingToStore(o);
            dto.requeueBlockedByUnreconciledCash = CashSemantics.BlocksFailedRequeue(
                o.Status, o.CashCollected, o.CashHandedOverAmount);
            dto.requeueBlockReason = dto.requeueBlockedByUnreconciledCash
                ? $"Cannot requeue: {o.CashCollected:0.00} cash was collected on this Failed order. " +
                  "Requeue stays blocked after handover — a second rider must not inherit or overwrite " +
                  "prior cash fields. Cancel instead, or await a per-rider cash ledger. " +
                  "Collected/handover amounts are preserved."
                : null;
            dto.items = (o.Items ?? Enumerable.Empty<AssignedOrderItem>())
                .Select(i => new AssignOrderItemDto
                {
                    itemId = i.ItemId,
                    description = i.Description,
                    position = i.Position,
                    quantity = i.Quantity,
                    comment = i.Comment,
                    lineNum = i.LineNum,
                    size = i.Size
                })
                .ToList();
            return dto;
        }

        private static AdminDeliveryIssueReportDto MapIssueReportDto(DeliveryIssueReport r) => new()
        {
            id = r.Id,
            assignedOrderId = r.AssignedOrderId,
            orderId = r.Order?.OrderId,
            orderNo = r.Order?.OrderNo,
            storeId = r.Order?.Batch?.StoreId,
            orderStatus = r.Order?.Status,
            riderUserId = r.RiderUserId,
            riderWorkerId = r.Rider?.ThirdPartyEmployeeId,
            riderName = r.Rider?.UserName,
            reasonCode = r.ReasonCode,
            reasonLabel = DeliveryIssueReasons.DisplayLabel(r.ReasonCode),
            note = r.Note,
            status = r.Status ?? DeliveryIssueStatuses.New,
            statusLabel = DeliveryIssueStatuses.DisplayLabel(r.Status ?? DeliveryIssueStatuses.New),
            internalNote = r.InternalNote,
            acknowledgedByUserId = r.AcknowledgedByUserId,
            acknowledgedByName = r.AcknowledgedByUser?.UserName,
            acknowledgedAt = r.AcknowledgedAt,
            closedByUserId = r.ClosedByUserId,
            closedByName = r.ClosedByUser?.UserName,
            closedAt = r.ClosedAt,
            createdAt = r.CreatedAt,
            updatedAt = r.UpdatedAt == default ? r.CreatedAt : r.UpdatedAt,
            rowVersion = r.RowVersion == null || r.RowVersion.Length == 0
                ? ""
                : Convert.ToBase64String(r.RowVersion)
        };

        private static List<string> RolesOf(AppUser user) =>
            user.UserRoles?
                .Where(ur => ur.Role != null && ur.Role.IsActive)
                .Select(ur => ur.Role.RoleName)
                .Distinct()
                .ToList() ?? new List<string>();

        private static bool IsRider(AppUser user) =>
            RolesOf(user).Contains(RoleNames.Rider);

        private static bool CanSeeStore(AdminActor actor, string storeId)
        {
            if (actor.IsHeadOffice)
                return true;
            if (string.IsNullOrWhiteSpace(actor.StoreId))
                return false;
            return string.Equals(actor.StoreId, storeId, StringComparison.OrdinalIgnoreCase);
        }

        private static (bool denied, string storeId, string message) ScopeStore(AdminActor actor, string requested)
        {
            if (actor.IsHeadOffice)
                return (false, string.IsNullOrWhiteSpace(requested) ? null : requested.Trim(), null);

            if (string.IsNullOrWhiteSpace(actor.StoreId))
                return (true, null, "Store manager has no store assigned");

            if (!string.IsNullOrWhiteSpace(requested)
                && !string.Equals(requested.Trim(), actor.StoreId, StringComparison.OrdinalIgnoreCase))
                return (true, null, "You can only view your assigned store");

            return (false, actor.StoreId, null);
        }

        private static (DateTime? fromUtc, DateTime? toUtc) NormalizeRange(DateTime? from, DateTime? to, int? defaultDays = null)
        {
            DateTime? fromUtc = from.HasValue ? ToUtc(from.Value) : null;
            DateTime? toUtc = to.HasValue ? ToUtc(to.Value) : null;

            if (fromUtc == null && toUtc == null && defaultDays.HasValue)
            {
                var end = DateTime.UtcNow.Date.AddDays(1);
                return (end.AddDays(-defaultDays.Value), end);
            }

            if (toUtc.HasValue && toUtc.Value.TimeOfDay == TimeSpan.Zero)
                toUtc = toUtc.Value.AddDays(1);

            return (fromUtc, toUtc);
        }

        private static DateTime ToUtc(DateTime value)
            => value.Kind == DateTimeKind.Unspecified
                ? DateTime.SpecifyKind(value, DateTimeKind.Utc)
                : value.ToUniversalTime();

        /// <summary>Expected COD due from customer — never OrderTotal for prepaid.</summary>
        private static decimal ExpectedCashDue(AssignedOrder o)
            => o.ExpectedCash ?? (IsCash(o.PaymentMethod) ? (o.Cash ?? 0) : 0);

        /// <summary>
        /// Actual cash held by rider for the store: collected minus handed over.
        /// Does NOT treat expected-but-uncollected COD as cash held (that is a receivable, not held cash).
        /// Legacy ambiguous rows are excluded from definitive balances.
        /// </summary>
        private static decimal CashOutstandingToStore(AssignedOrder o)
        {
            if (string.Equals(o.CashSemanticsNote, CashSemantics.LegacyAmbiguous, StringComparison.OrdinalIgnoreCase))
                return 0;

            if (!o.CashCollected.HasValue)
                return 0;

            var handed = o.CashHandedOverAmount ?? 0;
            return Math.Max(0, o.CashCollected.Value - handed);
        }

        /// <summary>Expected COD due from customer — never OrderTotal for prepaid. Reporting only.</summary>
        private static decimal ExpectedCashReceivable(AssignedOrder o)
        {
            if (o.CashCollected.HasValue)
                return 0;
            return ExpectedCashDue(o);
        }

        private static bool IsCash(string method)
        {
            if (string.IsNullOrWhiteSpace(method))
                return false;
            var m = method.Trim().ToLowerInvariant();
            return m is "cash" or "cod" or "c";
        }

        private static bool IsCard(string method)
        {
            if (string.IsNullOrWhiteSpace(method))
                return false;
            var m = method.Trim().ToLowerInvariant();
            return m is "card" or "credit" or "debit" or "visa" or "mastercard";
        }

        private static byte[] ToCsv(List<string[]> rows)
        {
            var sb = new StringBuilder();
            sb.Append('\uFEFF');
            foreach (var row in rows)
            {
                sb.AppendLine(string.Join(",", row.Select(CsvEscape)));
            }
            return Encoding.UTF8.GetBytes(sb.ToString());
        }

        private static string CsvEscape(string value)
        {
            value ??= "";
            if (value.Contains('"') || value.Contains(',') || value.Contains('\n') || value.Contains('\r'))
                return "\"" + value.Replace("\"", "\"\"") + "\"";
            return value;
        }

        private static byte[] ToSpreadsheetMl(List<string[]> rows)
        {
            var sb = new StringBuilder();
            sb.AppendLine(@"<?xml version=""1.0""?>");
            sb.AppendLine(@"<?mso-application progid=""Excel.Sheet""?>");
            sb.AppendLine(@"<Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet"" xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet"">");
            sb.AppendLine(@"<Worksheet ss:Name=""Settlements""><Table>");
            foreach (var row in rows)
            {
                sb.Append("<Row>");
                foreach (var cell in row)
                {
                    var escaped = System.Security.SecurityElement.Escape(cell ?? "") ?? "";
                    sb.Append($@"<Cell><Data ss:Type=""String"">{escaped}</Data></Cell>");
                }
                sb.AppendLine("</Row>");
            }
            sb.AppendLine("</Table></Worksheet></Workbook>");
            return Encoding.UTF8.GetBytes(sb.ToString());
        }

        private static ApiResponse<T> Ok<T>(T data, string message) => new(true, message, data);
        private static ApiResponse<T> Fail<T>(string message) => new(false, message, default);
    }
}
