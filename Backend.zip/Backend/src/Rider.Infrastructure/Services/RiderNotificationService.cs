using Rider.Application.DTOs.Notifications;
using Rider.Application.Interfaces;
using Rider.Application.Interfaces.Repositories;
using Rider.Domain.Common;
using Rider.Domain.Entities;

namespace Rider.Infrastructure.Services
{
    public class RiderNotificationService : IRiderNotificationService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IFcmPushService _fcm;

        public RiderNotificationService(IUnitOfWork unitOfWork, IFcmPushService fcm)
        {
            _unitOfWork = unitOfWork;
            _fcm = fcm;
        }

        public async Task<ApiResponse<List<RiderNotificationDto>>> ListForUserAsync(Guid userId, int take = 50)
        {
            var rows = await _unitOfWork.RiderNotificationRepository.ListForUserAsync(userId, take);
            return Ok(rows.Select(Map).ToList(), "Notifications");
        }

        public async Task<ApiResponse<string>> MarkReadAsync(Guid userId, long notificationId)
        {
            var row = await _unitOfWork.RiderNotificationRepository.GetForUserAsync(userId, notificationId);
            if (row == null)
                return Fail("Notification not found");

            row.IsRead = true;
            await _unitOfWork.RiderNotificationRepository.UpdateAsync(row);
            await _unitOfWork.SaveChangesAsync();
            return Ok("", "Marked read");
        }

        public async Task<ApiResponse<string>> MarkAllReadAsync(Guid userId)
        {
            var rows = await _unitOfWork.RiderNotificationRepository.ListForUserAsync(userId, 200);
            foreach (var row in rows.Where(r => !r.IsRead))
            {
                row.IsRead = true;
                await _unitOfWork.RiderNotificationRepository.UpdateAsync(row);
            }

            await _unitOfWork.SaveChangesAsync();
            return Ok("", "All marked read");
        }

        public async Task<ApiResponse<string>> SoftDeleteAsync(Guid userId, long notificationId)
        {
            var ok = await _unitOfWork.RiderNotificationRepository.SoftDeleteForUserAsync(
                userId, notificationId);
            if (!ok)
                return Fail("Notification not found");

            await _unitOfWork.SaveChangesAsync();
            return Ok("", "Notification deleted");
        }

        public async Task<ApiResponse<string>> SoftDeleteAllAsync(Guid userId)
        {
            await _unitOfWork.RiderNotificationRepository.SoftDeleteAllForUserAsync(userId);
            await _unitOfWork.SaveChangesAsync();
            return Ok("", "All notifications deleted");
        }

        public async Task NotifyDirectAssignmentAsync(
            Guid riderUserId, string orderId, long? assignedOrderId, string storeId, decimal orderTotal)
        {
            await CreateAndPushAsync(
                riderUserId,
                "orders",
                "New delivery assigned to you",
                $"Order {orderId} from Store {storeId} · Rs {orderTotal:N2}",
                orderId,
                assignedOrderId,
                "high");
        }

        public async Task NotifyOpenPoolOrderAsync(
            string orderId, long? assignedOrderId, string storeId, decimal orderTotal)
        {
            var riders = await _unitOfWork.UserRepository.ListActiveRidersForStoreAsync(storeId);
            foreach (var rider in riders)
            {
                await CreateAndPushAsync(
                    rider.UserId,
                    "orders",
                    "New delivery nearby",
                    $"Order {orderId} · Store {storeId} · Rs {orderTotal:N2}",
                    orderId,
                    assignedOrderId,
                    "high");
            }
        }

        public async Task NotifyOrderCancelledAsync(
            Guid riderUserId,
            string orderId,
            long? assignedOrderId,
            string? cancelReason)
        {
            var reason = string.IsNullOrWhiteSpace(cancelReason)
                ? "Cancelled by admin"
                : cancelReason.Trim();
            var body = $"Order {orderId} was cancelled. {reason}";

            await CreateAndPushAsync(
                riderUserId,
                "orders",
                RiderNotificationTitles.OrderCancelled,
                body,
                orderId,
                assignedOrderId,
                "high",
                extraData: new Dictionary<string, string>
                {
                    ["event"] = "order_cancelled",
                    ["assignedOrderId"] = assignedOrderId?.ToString() ?? ""
                });
        }

        public async Task<ApiResponse<SendNotificationResultDto>> SendTestToUserAsync(
            SendNotificationRequest request)
        {
            if (request == null || request.userId == Guid.Empty)
                return FailResult("userId is required");

            var user = await _unitOfWork.UserRepository.GetByUserIdAsync(request.userId);
            if (user == null)
                return FailResult("User not found");

            var title = string.IsNullOrWhiteSpace(request.title) ? "Test notification" : request.title.Trim();
            var body = string.IsNullOrWhiteSpace(request.body) ? "Hello from Maison Rider API" : request.body.Trim();
            var category = string.IsNullOrWhiteSpace(request.category) ? "system" : request.category.Trim();
            var priority = string.IsNullOrWhiteSpace(request.priority) ? "high" : request.priority.Trim();

            await CreateAndPushAsync(
                request.userId,
                category,
                title,
                body,
                orderId: null,
                assignedOrderId: null,
                priority);

            return Ok(
                new SendNotificationResultDto
                {
                    recipientCount = 1,
                    userIds = new List<Guid> { request.userId },
                    message = "Notification sent to user"
                },
                "Sent");
        }

        public async Task<ApiResponse<SendNotificationResultDto>> BroadcastTestAsync(
            BroadcastNotificationRequest request)
        {
            request ??= new BroadcastNotificationRequest();

            var title = string.IsNullOrWhiteSpace(request.title) ? "Broadcast test" : request.title.Trim();
            var body = string.IsNullOrWhiteSpace(request.body)
                ? "Hello from Maison Rider API (broadcast)"
                : request.body.Trim();
            var category = string.IsNullOrWhiteSpace(request.category) ? "system" : request.category.Trim();
            var priority = string.IsNullOrWhiteSpace(request.priority) ? "high" : request.priority.Trim();

            var riders = await _unitOfWork.UserRepository.ListActiveRidersForStoreAsync(request.storeId);
            var userIds = new List<Guid>();

            foreach (var rider in riders)
            {
                await CreateAndPushAsync(
                    rider.UserId,
                    category,
                    title,
                    body,
                    orderId: null,
                    assignedOrderId: null,
                    priority);
                userIds.Add(rider.UserId);
            }

            return Ok(
                new SendNotificationResultDto
                {
                    recipientCount = userIds.Count,
                    userIds = userIds,
                    message = string.IsNullOrWhiteSpace(request.storeId)
                        ? $"Broadcast sent to {userIds.Count} active rider(s)"
                        : $"Broadcast sent to {userIds.Count} active rider(s) for store {request.storeId}"
                },
                "Broadcast sent");
        }

        private async Task CreateAndPushAsync(
            Guid userId,
            string category,
            string title,
            string description,
            string orderId,
            long? assignedOrderId,
            string priority,
            IReadOnlyDictionary<string, string>? extraData = null)
        {
            var row = await CreateAsync(
                userId,
                category,
                title,
                description,
                orderId,
                assignedOrderId,
                priority);

            var data = new Dictionary<string, string>
            {
                ["category"] = category,
                ["orderId"] = orderId ?? "",
                ["notificationId"] = row.Id.ToString()
            };
            if (extraData != null)
            {
                foreach (var kv in extraData)
                    data[kv.Key] = kv.Value ?? "";
            }

            await _fcm.SendToUserAsync(userId, title, description, data);
        }

        private async Task<RiderNotification> CreateAsync(
            Guid userId,
            string category,
            string title,
            string description,
            string orderId,
            long? assignedOrderId,
            string priority)
        {
            var row = new RiderNotification
            {
                UserId = userId,
                Category = category,
                Title = title,
                Description = description,
                OrderId = orderId,
                AssignedOrderId = assignedOrderId,
                Priority = priority,
                IsRead = false,
                CreatedAt = DateTime.UtcNow
            };
            await _unitOfWork.RiderNotificationRepository.AddAsync(row);
            await _unitOfWork.SaveChangesAsync();
            return row;
        }

        private static RiderNotificationDto Map(RiderNotification n) => new()
        {
            id = n.Id,
            category = n.Category,
            title = n.Title,
            description = n.Description,
            orderId = n.OrderId,
            assignedOrderId = n.AssignedOrderId,
            priority = n.Priority,
            read = n.IsRead,
            // EF returns Unspecified; mark Utc so JSON emits Z (global converter also covers this).
            createdAt = n.CreatedAt.Kind == DateTimeKind.Utc
                ? n.CreatedAt
                : DateTime.SpecifyKind(n.CreatedAt, DateTimeKind.Utc)
        };

        private static ApiResponse<T> Ok<T>(T data, string message) => new(true, message, data);
        private static ApiResponse<string> Fail(string message) => new(false, message, null);
        private static ApiResponse<SendNotificationResultDto> FailResult(string message)
            => new(false, message, null);
    }
}

