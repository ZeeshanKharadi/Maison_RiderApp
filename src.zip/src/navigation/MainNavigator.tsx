import React from 'react';
import { View } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import TabNavigator from './TabNavigator';
import SideMenu from '../components/SideMenu';
import { NotificationHandler } from '../components/NotificationHandler';
import { SideMenuProvider } from '../context/SideMenuContext';
import { NetworkConnectivityProvider } from '../connectivity/NetworkConnectivityContext';
import { RiderSessionProvider } from '../context/RiderSessionContext';
import { AvailableOrdersProvider } from '../context/AvailableOrdersContext';
import { AccountProvider } from '../context/AccountContext';
import { useRiderNotificationPoll } from '../hooks/useRiderNotificationPoll';
import HistoryScreen from '../screens/HistoryScreen';
import PerformanceScreen from '../screens/PerformanceScreen';
import NotificationsScreen from '../screens/NotificationsScreen';
import SettingsScreen from '../screens/SettingsScreen';
import HelpScreen from '../screens/HelpScreen';
import OrderDetailsScreen from '../screens/OrderDetailsScreen';
import ActiveDeliveryScreen from '../screens/ActiveDeliveryScreen';
import DeliveryMapScreen from '../screens/DeliveryMapScreen';

export type DeliveryMapPreviewParams = {
  backendId?: number;
  restaurant?: string;
  customerName?: string;
  customerPhone?: string;
  pickupAddress?: string;
  dropoffAddress?: string;
  storeLat?: number | null;
  storeLng?: number | null;
  customerLat?: number | null;
  customerLng?: number | null;
  /** Prefer store until pickup; customer after — offer preview only */
  stateHint?: 'store' | 'customer';
};

export type MainStackParamList = {
  Tabs: undefined;
  RouteHistory: undefined;
  Performance: undefined;
  Notifications: undefined;
  Settings: undefined;
  Help: { section?: 'faq' | 'support' | 'report' | 'feedback' | 'privacy' | 'terms' } | undefined;
  OrderDetails: { orderId: string; backendId?: number };
  ActiveDelivery: { openReportIssue?: boolean } | undefined;
  DeliveryMap: {
    orderId: string;
    /** Used only when order is not (yet) in RiderSession — never after assignment ends */
    preview?: DeliveryMapPreviewParams;
  };
};

const Stack = createStackNavigator<MainStackParamList>();

function RiderNotificationPoller() {
  useRiderNotificationPoll(true);
  return null;
}

export default function MainNavigator() {
  return (
    <SideMenuProvider>
      <NetworkConnectivityProvider>
        <RiderSessionProvider>
          <AvailableOrdersProvider>
            <AccountProvider>
              <NotificationHandler />
              <RiderNotificationPoller />
              <View style={{ flex: 1 }}>
                <Stack.Navigator screenOptions={{ headerShown: false }}>
                  <Stack.Screen name="Tabs" component={TabNavigator} />
                  <Stack.Screen name="RouteHistory" component={HistoryScreen} />
                  <Stack.Screen name="Performance" component={PerformanceScreen} />
                  <Stack.Screen
                    name="Notifications"
                    component={NotificationsScreen}
                  />
                  <Stack.Screen name="Settings" component={SettingsScreen} />
                  <Stack.Screen name="Help" component={HelpScreen} />
                  <Stack.Screen name="OrderDetails" component={OrderDetailsScreen} />
                  <Stack.Screen
                    name="ActiveDelivery"
                    component={ActiveDeliveryScreen}
                  />
                  <Stack.Screen
                    name="DeliveryMap"
                    component={DeliveryMapScreen}
                  />
                </Stack.Navigator>
                <SideMenu />
              </View>
            </AccountProvider>
          </AvailableOrdersProvider>
        </RiderSessionProvider>
      </NetworkConnectivityProvider>
    </SideMenuProvider>
  );
}
