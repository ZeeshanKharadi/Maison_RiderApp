import { PermissionsAndroid, Platform } from 'react-native';
import {
  AuthorizationStatus,
  getInitialNotification,
  getMessaging,
  getToken,
  onMessage,
  onNotificationOpenedApp,
  onTokenRefresh,
  registerDeviceForRemoteMessages,
  requestPermission,
  type RemoteMessage,
} from '@react-native-firebase/messaging';
import notifee, { AndroidImportance, EventType } from '@notifee/react-native';
import * as deviceTokenRepository from '../repositories/deviceTokenRepository';
import * as notificationsRepository from '../repositories/notificationsRepository';
import { navigationRef, navigate } from '../navigation/RootNavigation';
import {
  applyPushSyncIntent,
  resolvePushSyncIntent,
  shouldRegisterPushToken,
} from '../utils/pushRegistration';

const CHANNEL_ID = 'maison_orders';
const messaging = getMessaging();

class NotificationService {
  private fcmToken: string | null = null;
  private listenersSetup = false;
  /** Mirrors Settings pushNotifications; gates register / token-refresh. */
  private pushPreferred = true;

  setPushPreferred(enabled: boolean): void {
    this.pushPreferred = enabled;
  }

  getPushPreferred(): boolean {
    return this.pushPreferred;
  }

  async initializeChannels(): Promise<void> {
    if (Platform.OS !== 'android') return;
    await notifee.createChannel({
      id: CHANNEL_ID,
      name: 'Order assignments',
      importance: AndroidImportance.HIGH,
      vibration: true,
      sound: 'default',
    });
  }

  async requestNotificationPermission(): Promise<boolean> {
    try {
      if (Platform.OS === 'ios') {
        const authStatus = await requestPermission(messaging);
        const granted =
          authStatus === AuthorizationStatus.AUTHORIZED ||
          authStatus === AuthorizationStatus.PROVISIONAL;
        if (granted) {
          await registerDeviceForRemoteMessages(messaging);
        }
        return granted;
      }

      const version =
        typeof Platform.Version === 'string'
          ? parseInt(Platform.Version, 10)
          : Platform.Version;

      if (version >= 33) {
        const result = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS,
          {
            title: 'Show Notifications',
            message:
              'This app needs notification permission to alert you about new delivery assignments.',
            buttonPositive: 'Allow',
            buttonNegative: "Don't Allow",
          },
        );
        if (result !== PermissionsAndroid.RESULTS.GRANTED) {
          return false;
        }
      }

      await getToken(messaging);
      return true;
    } catch {
      return false;
    }
  }

  async getFcmToken(): Promise<string | null> {
    try {
      if (Platform.OS === 'ios') {
        await registerDeviceForRemoteMessages(messaging);
      }
      const token = await getToken(messaging);
      this.fcmToken = token;
      return token;
    } catch {
      return null;
    }
  }

  /**
   * POST this device token when push is preferred.
   * No-ops (success) when the rider turned push off.
   */
  async saveTokensToBackend(): Promise<boolean> {
    if (!shouldRegisterPushToken(this.pushPreferred)) {
      return true;
    }

    const token = await this.getFcmToken();
    if (!token) return false;

    const result = await deviceTokenRepository.registerDeviceToken(
      token,
      Platform.OS === 'ios' ? 'ios' : 'android',
    );
    if (!result.ok) {
      console.warn('[FCM] Backend registration failed:', result.error.message);
      return false;
    }

    this.fcmToken = token;
    return true;
  }

  /** Cached FCM token if known; otherwise fetches from Firebase. */
  async peekFcmToken(): Promise<string | null> {
    if (this.fcmToken) return this.fcmToken;
    return this.getFcmToken();
  }

  /** DELETE this device token on the server. Keeps local FCM token for re-register. */
  async removeTokenFromBackend(): Promise<boolean> {
    const token = this.fcmToken ?? (await this.getFcmToken());
    if (!token) return true;

    const result = await deviceTokenRepository.removeDeviceToken(token);
    if (!result.ok) {
      console.warn('[FCM] Backend removal failed:', result.error.message);
      return false;
    }
    return true;
  }

  /**
   * Apply Settings push switch to server registration for this device.
   * Caller should persist the preference only when ok is true.
   */
  async applyPushPreference(
    enabled: boolean,
  ): Promise<{ ok: true } | { ok: false; message: string }> {
    const previous = this.pushPreferred;
    const intent = resolvePushSyncIntent(enabled);
    this.pushPreferred = enabled;

    if (intent === 'register') {
      const granted = await this.requestNotificationPermission();
      if (!granted) {
        this.pushPreferred = previous;
        return {
          ok: false,
          message:
            'Notification permission is off. Enable it in system Settings, then try again.',
        };
      }
    }

    const result = await applyPushSyncIntent({
      intent,
      register: () => this.saveTokensToBackend(),
      unregister: () => this.removeTokenFromBackend(),
    });

    if (!result.ok) {
      this.pushPreferred = previous;
    }
    return result;
  }

  async showNotification(
    remoteMessage: RemoteMessage,
    notificationId?: string,
  ): Promise<void> {
    if (!this.pushPreferred) return;

    await this.initializeChannels();

    const title =
      remoteMessage.notification?.title ||
      remoteMessage.data?.title ||
      'Notification';
    const body =
      remoteMessage.notification?.body ||
      remoteMessage.data?.body ||
      remoteMessage.data?.message ||
      '';

    await notifee.displayNotification({
      id:
        notificationId ||
        remoteMessage.messageId ||
        `notif_${Date.now()}`,
      title: String(title),
      body: String(body),
      data: (remoteMessage.data as Record<string, string>) || {},
      android: {
        channelId: CHANNEL_ID,
        smallIcon: 'ic_launcher',
        color: '#C8102E',
        importance: AndroidImportance.HIGH,
        pressAction: { id: 'default' },
        autoCancel: true,
      },
      ios: {
        sound: 'default',
        foregroundPresentationOptions: {
          alert: true,
          badge: true,
          sound: true,
        },
      },
    });
  }

  async showLocalNotification(
    title: string,
    body: string,
    data?: Record<string, string>,
  ): Promise<void> {
    if (!this.pushPreferred) return;

    await this.initializeChannels();
    await notifee.displayNotification({
      id: `local_${Date.now()}`,
      title,
      body,
      data: data || {},
      android: {
        channelId: CHANNEL_ID,
        smallIcon: 'ic_launcher',
        color: '#C8102E',
        importance: AndroidImportance.HIGH,
        pressAction: { id: 'default' },
        autoCancel: true,
      },
    });
  }

  setupNotificationListeners(options: {
    incrementUnreadCount: () => void;
    onOrderNotification?: (data?: Record<string, string>) => void;
  }): () => void {
    if (this.listenersSetup) {
      return () => {};
    }
    this.listenersSetup = true;

    const queue = new Set<string>();

    const unsubscribeForeground = onMessage(messaging, async remoteMessage => {
      const notificationId =
        remoteMessage.messageId ||
        remoteMessage.data?.messageId ||
        `fg_${Date.now()}`;

      if (queue.has(String(notificationId))) return;
      queue.add(String(notificationId));
      setTimeout(() => queue.delete(String(notificationId)), 2000);

      // Still handle order side-effects (e.g. cancel restore) when push is OFF;
      // only the visible toast is gated by pushPreferred inside showNotification.
      if (this.pushPreferred) {
        await this.showNotification(remoteMessage, String(notificationId));
        options.incrementUnreadCount();
      }

      if (remoteMessage.data?.category === 'orders') {
        const data: Record<string, string> = {};
        const raw = remoteMessage.data || {};
        for (const [k, v] of Object.entries(raw)) {
          if (v != null) data[k] = String(v);
        }
        if (remoteMessage.notification?.title) {
          data.title = String(remoteMessage.notification.title);
        }
        options.onOrderNotification?.(data);
      }
    });

    const unsubscribeOpened = onNotificationOpenedApp(
      messaging,
      remoteMessage => {
        this.handleNotificationNavigation(remoteMessage.data);
      },
    );

    getInitialNotification(messaging).then(remoteMessage => {
      if (remoteMessage) {
        this.handleNotificationNavigation(remoteMessage.data);
      }
    });

    const notifeeUnsubscribe = notifee.onForegroundEvent(({ type, detail }) => {
      if (type === EventType.PRESS) {
        this.handleNotificationNavigation(detail.notification?.data);
      }
    });

    const unsubscribeTokenRefresh = onTokenRefresh(messaging, async () => {
      if (!shouldRegisterPushToken(this.pushPreferred)) return;
      await this.saveTokensToBackend();
    });

    return () => {
      this.listenersSetup = false;
      unsubscribeForeground();
      unsubscribeOpened();
      notifeeUnsubscribe();
      unsubscribeTokenRefresh();
    };
  }

  handleNotificationNavigation(data?: Record<string, unknown> | null): void {
    if (!data || !navigationRef.isReady()) return;
    if (
      data.category === 'orders' ||
      data.screen === 'notifications' ||
      data.screen === 'Notifications'
    ) {
      navigate('MainDrawer', { screen: 'Notifications' });
    }
  }

  fetchNotifications = notificationsRepository.fetchNotifications;
  markNotificationRead = notificationsRepository.markNotificationRead;
  markAllNotificationsRead = notificationsRepository.markAllNotificationsRead;
  deleteNotification = notificationsRepository.deleteNotification;
  deleteAllNotifications = notificationsRepository.deleteAllNotifications;
}

const notificationService = new NotificationService();
export default notificationService;
