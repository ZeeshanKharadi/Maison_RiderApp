import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  buildCancellationEventKey,
  filterUnacknowledgedCancellationKeys,
} from '../utils/cancellationAck';

const keyForUser = (userId: string) =>
  `@maison_rider/cancel_ack:${userId.trim().toLowerCase()}`;

export { buildCancellationEventKey as cancellationEventKey };
export { filterUnacknowledgedCancellationKeys as filterUnacknowledgedKeys };

export async function loadAcknowledgedCancellationKeys(
  userId: string,
): Promise<Set<string>> {
  if (!userId.trim()) return new Set();
  try {
    const raw = await AsyncStorage.getItem(keyForUser(userId));
    if (!raw) return new Set();
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return new Set();
    return new Set(parsed.filter((x): x is string => typeof x === 'string'));
  } catch {
    return new Set();
  }
}

export async function acknowledgeCancellationKeys(
  userId: string,
  keys: string[],
): Promise<void> {
  if (!userId.trim() || keys.length === 0) return;
  const existing = await loadAcknowledgedCancellationKeys(userId);
  let changed = false;
  for (const k of keys) {
    if (!k || existing.has(k)) continue;
    existing.add(k);
    changed = true;
  }
  if (!changed) return;
  const list = [...existing];
  const trimmed = list.length > 200 ? list.slice(list.length - 200) : list;
  await AsyncStorage.setItem(keyForUser(userId), JSON.stringify(trimmed));
}
