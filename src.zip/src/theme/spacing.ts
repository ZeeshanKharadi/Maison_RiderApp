/**
 * 8pt spacing system (+ 4pt half-step for tight gaps).
 */
export const spacing = {
  xxs: 4,
  xs: 8,
  sm: 12,
  md: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 40,
} as const;

export type SpacingToken = keyof typeof spacing;

/** Minimum touch target size (accessibility). */
export const TOUCH_TARGET = 44;
