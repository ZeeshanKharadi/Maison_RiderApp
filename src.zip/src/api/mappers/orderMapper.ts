import { AvailableOrder, PaymentMethod, TimelineEvent } from '../../data/orders';
import { DeliveryState } from '../../delivery/stateMachine';
import { parseApiDate, toApiIso, toApiIsoPrefer } from '../../utils/apiDate';

/** Matches backend AvailableOrderDto / AssignOrderItemDto */
export type ApiOrderItem = {
  itemId: number;
  description?: string | null;
  position?: string | null;
  quantity: number;
  comment?: string | null;
  lineNum?: string | null;
  size?: string | null;
};

export type ApiAvailableOrder = {
  id: number;
  orderId: string;
  orderNo?: string | null;
  displayOrderNo?: string | null;
  storeId?: string | null;
  storeLat?: number | null;
  storeLng?: number | null;
  orderTypeId?: string | null;
  orderState?: string | null;
  status?: string | null;
  comment?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  city?: string | null;
  street?: string | null;
  addressNo?: string | null;
  postCode?: string | null;
  secondaryAddress?: string | null;
  lat?: number | null;
  lng?: number | null;
  phone?: string | null;
  orderTotal: number;
  paymentMethod?: string | null;
  cash?: number | null;
  expectedCash?: number | null;
  cashCollected?: number | null;
  cashCollectedReason?: string | null;
  orderTime?: string | null;
  batchTime?: string | null;
  createdAt: string;
  /** Last Available re-push; prefer over createdAt for "posted ago". */
  updatedAt?: string | null;
  acceptedAt?: string | null;
  pickedUpAt?: string | null;
  completedAt?: string | null;
  isDirectAssignment?: boolean;
  items?: ApiOrderItem[];
  issueReports?: Array<{
    id: number;
    assignedOrderId: number;
    orderId?: string;
    orderNo?: string;
    storeId?: string;
    reasonCode: string;
    reasonLabel?: string;
    note?: string | null;
    riderUserId: string;
    requestId?: string | null;
    createdAt: string;
    orderStatus?: string;
    status?: string;
    statusLabel?: string;
    acknowledgedAt?: string | null;
    closedAt?: string | null;
  }>;
  failure?: {
    requestStatus?: string | null;
    reasonCode?: string | null;
    reasonLabel?: string | null;
    note?: string | null;
    requestId?: string | null;
    issueReportId?: number | null;
    requestedAt?: string | null;
    decidedAt?: string | null;
    decisionNote?: string | null;
    statusBeforeReturn?: string | null;
    riderReturnedAt?: string | null;
    storeReceivedAt?: string | null;
    cashCollectedWarning?: boolean;
    cashCollected?: number | null;
    expectedCash?: number | null;
  } | null;
};

export type ApiRiderPerformance = {
  completedCount: number;
  avgDurationMinutes?: number | null;
  onlineHours: number;
  codCollected: number;
  codOutstanding: number;
  from?: string | null;
  to?: string | null;
  payoutMode?: string | null;
  payoutFixedFee?: number | null;
  estimatedDeliveryPay?: number | null;
  deliveryPayAvailable?: boolean;
  deliveryPayNote?: string | null;
};

const IMAGE_COLORS = [
  '#FFB74D',
  '#81C784',
  '#E57373',
  '#64B5F6',
  '#BA68C8',
  '#4DB6AC',
  '#FF8A65',
];

function joinParts(...parts: Array<string | null | undefined>): string {
  return parts
    .map(p => (p ?? '').trim())
    .filter(Boolean)
    .join(', ');
}

/**
 * Align with backend IsCash / IsCard (AdminService) and OrderService.IsCashMethod.
 * Do not default unknown methods to card — that would falsely imply prepaid/paid.
 */
function mapPaymentMethod(
  paymentMethod?: string | null,
  cash?: number | null,
): PaymentMethod {
  const raw = (paymentMethod ?? '').trim().toLowerCase();
  if (
    raw === '1' ||
    raw === 'c' ||
    raw === 'cash' ||
    raw === 'cod' ||
    (cash != null && Number(cash) > 0)
  ) {
    return 'cash';
  }
  if (
    raw === '2' ||
    raw === 'card' ||
    raw === 'credit' ||
    raw === 'debit' ||
    raw === 'visa' ||
    raw === 'mastercard'
  ) {
    return 'card';
  }
  if (raw === 'wallet' || raw === '3') return 'wallet';
  return 'unknown';
}

/** Matches OrderService.RequiresCashOnComplete: cash method or expected cash due. */
function isCodOrder(
  paymentMethod?: string | null,
  cash?: number | null,
  expectedCash?: number | null,
): boolean {
  if (mapPaymentMethod(paymentMethod, cash) === 'cash') return true;
  return expectedCash != null && Number.isFinite(Number(expectedCash)) && Number(expectedCash) > 0;
}

function buildTimeline(
  /** Sticky CreatedAt only — never UpdatedAt / never invent now. */
  createdAtIso: string | null,
  acceptedAt?: string | null,
  pickedUpAt?: string | null,
): TimelineEvent[] {
  const createdIso = createdAtIso && createdAtIso.trim() ? createdAtIso : '';
  const acceptedIso = toApiIso(acceptedAt, false);
  const pickedUpIso = toApiIso(pickedUpAt, false);
  const acceptedDone = !!acceptedIso;
  const pickupDone = !!pickedUpIso;

  return [
    {
      id: 'created',
      label: 'Order created',
      at: createdIso,
      done: !!createdIso,
    },
    {
      id: 'assigned',
      label: 'Assigned via AssignOrder',
      at: createdIso,
      done: !!createdIso,
    },
    {
      id: 'offered',
      label: 'Offered to you',
      at: createdIso,
      done: !!createdIso,
    },
    {
      id: 'accepted',
      label: 'Accepted',
      at: acceptedDone ? acceptedIso : '',
      done: acceptedDone,
    },
    {
      id: 'pickup',
      label: pickupDone ? 'Picked up' : 'Pickup pending',
      at: pickupDone ? pickedUpIso : '',
      done: pickupDone,
    },
  ];
}

function colorForId(key: string): string {
  let hash = 0;
  for (let i = 0; i < key.length; i += 1) {
    hash = (hash * 31 + key.charCodeAt(i)) | 0;
  }
  return IMAGE_COLORS[Math.abs(hash) % IMAGE_COLORS.length];
}

/**
 * Maps AssignOrder-backed API rows into the UI AvailableOrder shape.
 */
export function mapApiOrderToAvailable(dto: ApiAvailableOrder): AvailableOrder {
  const externalId = (dto.orderId ?? '').trim();
  const shortOrderNo = (dto.orderNo ?? dto.displayOrderNo ?? '').trim();
  // Stable list/nav id: prefer real external id, else short no, else backend pk.
  const displayId = externalId || shortOrderNo || String(dto.id);
  const customerName = joinParts(dto.firstName, dto.lastName) || 'Customer';
  const dropoffAddress =
    joinParts(
      dto.addressNo,
      dto.street,
      dto.secondaryAddress,
      dto.city,
      dto.postCode,
    ) || 'Address unavailable';

  const lineItems = dto.items ?? [];
  const itemCount = lineItems.reduce(
    (sum, item) => sum + Math.max(1, item.quantity || 1),
    0,
  );
  const packageInfo =
    lineItems
      .map(item => {
        const bits = [item.description, item.size, item.comment]
          .map(v => (v ?? '').trim())
          .filter(Boolean);
        return bits.join(' · ');
      })
      .filter(Boolean)
      .join(' | ') || `${Math.max(itemCount, 1)} item(s)`;

  const comment = (dto.comment ?? '').trim();
  const paymentMethod = mapPaymentMethod(dto.paymentMethod, dto.cash);
  const storeLabel = dto.storeId ? `Store ${dto.storeId}` : 'Store';
  // Authoritative COD due — ExpectedCash, else Cash for cash method. Never OrderTotal.
  const expectedCash =
    dto.expectedCash != null && Number.isFinite(Number(dto.expectedCash))
      ? Number(dto.expectedCash)
      : paymentMethod === 'cash' &&
          dto.cash != null &&
          Number.isFinite(Number(dto.cash))
        ? Number(dto.cash)
        : null;
  const orderTotalNum =
    dto.orderTotal != null && Number.isFinite(Number(dto.orderTotal))
      ? Number(dto.orderTotal)
      : null;

  return {
    id: displayId,
    storeId: dto.storeId ?? undefined,
    storeLat: dto.storeLat ?? null,
    storeLng: dto.storeLng ?? null,
    restaurant: storeLabel,
    customerName,
    customerPhone: (dto.phone ?? '').trim() || '—',
    pickupAddress: storeLabel,
    dropoffAddress,
    customerLat: dto.lat ?? null,
    customerLng: dto.lng ?? null,
    distanceMiles: null,
    etaMinutes: null,
    orderAmount: orderTotalNum,
    deliveryFee: 0,
    paymentMethod,
    isCod: isCodOrder(dto.paymentMethod, dto.cash, expectedCash),
    priority: /fast|urgent|asap/i.test(comment) ? 'urgent' : 'normal',
    fragile: false,
    express: /fast|express|asap/i.test(comment),
    specialInstructions: comment || undefined,
    items: Math.max(itemCount, lineItems.length, 1),
    packageInfo,
    // CreatedAt = sticky insert (never UpdatedAt). Available since = UpdatedAt on re-push, else CreatedAt.
    createdAt: toApiIso(dto.createdAt, false) || null,
    availableSince:
      toApiIsoPrefer(dto.updatedAt, dto.createdAt, false) || null,
    // postedAt remains the offer-age stamp for sort/compat — not creation time.
    postedAt: toApiIsoPrefer(dto.updatedAt, dto.createdAt, false),
    imageColor: colorForId(displayId),
    timeline: buildTimeline(
      toApiIso(dto.createdAt, false) || null,
      dto.acceptedAt,
      dto.pickedUpAt,
    ),
    /** Internal PK for GET /api/Order/{id} */
    backendId: dto.id,
    externalOrderId: externalId || undefined,
    orderNo: shortOrderNo || undefined,
    expectedCash,
    cashCollectedAmount:
      dto.cashCollected != null && Number.isFinite(Number(dto.cashCollected))
        ? Number(dto.cashCollected)
        : null,
    cashCollectedReason: (dto.cashCollectedReason ?? '').trim() || null,
    backendStatus: dto.status ?? undefined,
    acceptedAt: toApiIso(dto.acceptedAt, false) || undefined,
    pickedUpAt: toApiIso(dto.pickedUpAt, false) || undefined,
    completedAt: toApiIso(dto.completedAt, false) || undefined,
    isDirectAssignment: dto.isDirectAssignment ?? false,
    issueReports: (dto.issueReports ?? []).map(r => ({
      id: r.id,
      reasonCode: r.reasonCode,
      reasonLabel: r.reasonLabel,
      note: r.note,
      createdAt: toApiIso(r.createdAt, false),
      status: r.status,
      statusLabel: r.statusLabel,
      acknowledgedAt: toApiIso(r.acknowledgedAt, false) || undefined,
      closedAt: toApiIso(r.closedAt, false) || undefined,
    })),
    failure: dto.failure
      ? {
          requestStatus: dto.failure.requestStatus ?? undefined,
          reasonCode: dto.failure.reasonCode ?? undefined,
          reasonLabel: dto.failure.reasonLabel ?? undefined,
          note: dto.failure.note ?? undefined,
          requestId: dto.failure.requestId ?? undefined,
          issueReportId: dto.failure.issueReportId ?? undefined,
          requestedAt: toApiIso(dto.failure.requestedAt, false) || undefined,
          decidedAt: toApiIso(dto.failure.decidedAt, false) || undefined,
          decisionNote: dto.failure.decisionNote ?? undefined,
          statusBeforeReturn: dto.failure.statusBeforeReturn ?? undefined,
          riderReturnedAt: toApiIso(dto.failure.riderReturnedAt, false) || undefined,
          storeReceivedAt: toApiIso(dto.failure.storeReceivedAt, false) || undefined,
          cashCollectedWarning: !!dto.failure.cashCollectedWarning,
          cashCollected: dto.failure.cashCollected ?? undefined,
          expectedCash: dto.failure.expectedCash ?? undefined,
        }
      : undefined,
  };
}

/** Map backend lifecycle status → local delivery UI state (no fabricated arrivals). */
export function mapBackendStatusToDeliveryState(
  status?: string | null,
): DeliveryState {
  const raw = (status ?? '').trim().toLowerCase();
  switch (raw) {
    case 'completed':
      return 'COMPLETED';
    case 'delivered':
      return 'DELIVERED';
    case 'arrivedatcustomer':
    case 'arrived_at_customer':
      return 'ARRIVED_AT_DESTINATION';
    case 'ontheway':
    case 'on_the_way':
      return 'ON_THE_WAY';
    case 'inprogress':
    case 'in_progress':
      return 'PICKUP_CONFIRMED';
    case 'arrivedatpickup':
    case 'arrived_at_pickup':
      return 'ARRIVED_AT_PICKUP';
    case 'navigatingtopickup':
    case 'navigating_to_pickup':
      return 'NAVIGATE_TO_PICKUP';
    case 'accepted':
      return 'ACCEPTED';
    case 'returningtostore':
    case 'returning_to_store':
      return 'RETURNING_TO_STORE';
    case 'awaitingstorereceipt':
    case 'awaiting_store_receipt':
      return 'AWAITING_STORE_RECEIPT';
    default:
      return 'ACCEPTED';
  }
}

/** Local delivery UI state → server AssignedOrders.Status. */
export function mapDeliveryStateToBackendStatus(
  state: DeliveryState,
): string {
  switch (state) {
    case 'ACCEPTED':
      return 'Accepted';
    case 'NAVIGATE_TO_PICKUP':
      return 'NavigatingToPickup';
    case 'ARRIVED_AT_PICKUP':
      return 'ArrivedAtPickup';
    case 'PICKUP_CONFIRMED':
      return 'InProgress';
    case 'ON_THE_WAY':
      return 'OnTheWay';
    case 'ARRIVED_AT_DESTINATION':
      return 'ArrivedAtCustomer';
    case 'DELIVERED':
      return 'Delivered';
    case 'COMPLETED':
      return 'Completed';
    case 'RETURNING_TO_STORE':
      return 'ReturningToStore';
    case 'AWAITING_STORE_RECEIPT':
      return 'AwaitingStoreReceipt';
    default:
      return 'Accepted';
  }
}

export function isCancelledBackendStatus(status?: string | null): boolean {
  const raw = (status ?? '').trim().toLowerCase();
  return raw === 'cancelled' || raw === 'canceled';
}

/** Statuses that still belong on the rider's Active list (server ActiveStatuses). */
export function isLiveRiderActiveStatus(status?: string | null): boolean {
  const raw = (status ?? '').trim().toLowerCase().replace(/_/g, '');
  switch (raw) {
    case 'accepted':
    case 'navigatingtopickup':
    case 'arrivedatpickup':
    case 'inprogress':
    case 'ontheway':
    case 'arrivedatcustomer':
    case 'delivered':
    case 'returningtostore':
    case 'awaitingstorereceipt':
      return true;
    default:
      // Available / Cancelled / Completed / Failed / unknown → not an active job
      return false;
  }
}
